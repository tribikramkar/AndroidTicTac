pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Meta Audience Network SDK repository — needed only once you wire up real ads.
        // maven { url = uri("https://facebook.jfrog.io/artifactory/maven") }
    }
}

rootProject.name = "TicTacToe"
include(":app")
