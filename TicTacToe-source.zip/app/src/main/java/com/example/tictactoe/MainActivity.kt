package com.example.tictactoe

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var boardView: GameBoardView
    private lateinit var statusText: TextView
    private lateinit var scoreText: TextView

    private var board = arrayOfNulls<Char>(9)
    private var current = 'X'
    private var gameOver = false

    private var scoreX = 0
    private var scoreO = 0
    private var scoreDraw = 0

    private val winLines = listOf(
        intArrayOf(0, 1, 2), intArrayOf(3, 4, 5), intArrayOf(6, 7, 8),
        intArrayOf(0, 3, 6), intArrayOf(1, 4, 7), intArrayOf(2, 5, 8),
        intArrayOf(0, 4, 8), intArrayOf(2, 4, 6)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        boardView = findViewById(R.id.gameBoard)
        statusText = findViewById(R.id.statusText)
        scoreText = findViewById(R.id.scoreText)

        boardView.onCellTapped = { index -> handleMove(index) }

        findViewById<Button>(R.id.newRoundBtn).setOnClickListener { newRound() }
        findViewById<Button>(R.id.resetScoreBtn).setOnClickListener {
            scoreX = 0; scoreO = 0; scoreDraw = 0
            updateScore()
            newRound()
        }

        // ---- Ad slot ----
        // See the comment block around #adSlot in activity_main.xml for the
        // three steps to load a real Meta Audience Network banner here, e.g.:
        //
        // val adSlot = findViewById<FrameLayout>(R.id.adSlot)
        // val adView = AdView(this, "YOUR_PLACEMENT_ID", AdSize.BANNER_HEIGHT_50)
        // adSlot.removeAllViews()
        // adSlot.addView(adView)
        // adView.loadAd()

        newRound()
    }

    private fun handleMove(index: Int) {
        if (gameOver || board[index] != null) return
        board[index] = current
        boardView.setBoard(board.copyOf(), animateCell = index)

        val win = checkWin()
        if (win != null) {
            gameOver = true
            boardView.showWinLine(win.first[0], win.first[2])
            statusText.text = "$current wins! \uD83C\uDF89"
            if (current == 'X') scoreX++ else scoreO++
            updateScore()
            return
        }
        if (board.all { it != null }) {
            gameOver = true
            statusText.text = getString(R.string.draw)
            scoreDraw++
            updateScore()
            return
        }
        current = if (current == 'X') 'O' else 'X'
        statusText.text = if (current == 'X') getString(R.string.turn_x) else getString(R.string.turn_o)
    }

    private fun checkWin(): Pair<IntArray, Char>? {
        for (line in winLines) {
            val (a, b, c) = Triple(line[0], line[1], line[2])
            val v = board[a]
            if (v != null && v == board[b] && v == board[c]) {
                return Pair(line, v)
            }
        }
        return null
    }

    private fun updateScore() {
        scoreText.text = "X: $scoreX    O: $scoreO    Draws: $scoreDraw"
    }

    private fun newRound() {
        board = arrayOfNulls(9)
        current = 'X'
        gameOver = false
        statusText.text = getString(R.string.turn_x)
        boardView.reset()
    }
}
