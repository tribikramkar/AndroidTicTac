package com.example.tictactoe

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat

/**
 * Chalk-drawn Tic-Tac-Toe board.
 * board[i] is null, 'X', or 'O' for cell i (0..8, row-major).
 */
class GameBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var board = arrayOfNulls<Char>(9)
        private set

    var onCellTapped: ((Int) -> Unit)? = null

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.chalk)
        strokeWidth = 10f
        strokeCap = Paint.Cap.ROUND
        alpha = 220
    }

    private val xPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.x_color)
        strokeWidth = 18f
        strokeCap = Paint.Cap.ROUND
        style = Paint.Style.STROKE
    }

    private val oPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.o_color)
        strokeWidth = 18f
        strokeCap = Paint.Cap.ROUND
        style = Paint.Style.STROKE
    }

    private val winPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.win_line)
        strokeWidth = 16f
        strokeCap = Paint.Cap.ROUND
    }

    // per-cell draw-in progress, 0f..1f
    private val cellProgress = FloatArray(9)

    private var winLine: IntArray? = null // [startCell, endCell]
    private var winProgress = 0f

    fun setBoard(newBoard: Array<Char?>, animateCell: Int? = null) {
        board = newBoard
        if (animateCell != null) {
            cellProgress[animateCell] = 0f
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 220
                interpolator = DecelerateInterpolator()
                addUpdateListener {
                    cellProgress[animateCell] = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else {
            for (i in 0..8) cellProgress[i] = if (board[i] != null) 1f else 0f
            invalidate()
        }
    }

    fun showWinLine(startCell: Int, endCell: Int) {
        winLine = intArrayOf(startCell, endCell)
        winProgress = 0f
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 300
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                winProgress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun reset() {
        board = arrayOfNulls(9)
        for (i in 0..8) cellProgress[i] = 0f
        winLine = null
        winProgress = 0f
        invalidate()
    }

    private fun cellCenter(index: Int, size: Float): Pair<Float, Float> {
        val cellSize = size / 3f
        val col = index % 3
        val row = index / 3
        return Pair(cellSize * col + cellSize / 2f, cellSize * row + cellSize / 2f)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(size, size)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = width.toFloat()
        val third = size / 3f

        // grid lines
        canvas.drawLine(third, size * 0.03f, third, size * 0.97f, gridPaint)
        canvas.drawLine(third * 2, size * 0.03f, third * 2, size * 0.97f, gridPaint)
        canvas.drawLine(size * 0.03f, third, size * 0.97f, third, gridPaint)
        canvas.drawLine(size * 0.03f, third * 2, size * 0.97f, third * 2, gridPaint)

        val markRadius = third * 0.28f

        for (i in 0..8) {
            val mark = board[i] ?: continue
            val progress = cellProgress[i]
            if (progress <= 0f) continue
            val (cx, cy) = cellCenter(i, size)

            if (mark == 'X') {
                val r = markRadius
                // first stroke draws over first half of progress, second stroke over second half
                val p1 = (progress * 2f).coerceAtMost(1f)
                val p2 = ((progress - 0.5f) * 2f).coerceIn(0f, 1f)
                if (p1 > 0f) {
                    canvas.drawLine(
                        cx - r, cy - r,
                        cx - r + (2 * r) * p1, cy - r + (2 * r) * p1,
                        xPaint
                    )
                }
                if (p2 > 0f) {
                    canvas.drawLine(
                        cx + r, cy - r,
                        cx + r - (2 * r) * p2, cy - r + (2 * r) * p2,
                        xPaint
                    )
                }
            } else if (mark == 'O') {
                val rect = RectF(cx - markRadius, cy - markRadius, cx + markRadius, cy + markRadius)
                canvas.drawArc(rect, -90f, 360f * progress, false, oPaint)
            }
        }

        winLine?.let { (start, end) ->
            val (sx, sy) = cellCenter(start, size)
            val (ex, ey) = cellCenter(end, size)
            val curX = sx + (ex - sx) * winProgress
            val curY = sy + (ey - sy) * winProgress
            canvas.drawLine(sx, sy, curX, curY, winPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            val third = width / 3f
            val col = (event.x / third).toInt().coerceIn(0, 2)
            val row = (event.y / third).toInt().coerceIn(0, 2)
            onCellTapped?.invoke(row * 3 + col)
            performClick()
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
