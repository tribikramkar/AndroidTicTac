# Tic Tac Toe (Android, Kotlin)

A native Android version of the chalkboard-style Tic-Tac-Toe game, with a
banner ad slot ready for Meta (Facebook) Audience Network.

## How to open and run

1. Install [Android Studio](https://developer.android.com/studio) (free).
2. Open Android Studio → **File → Open** → select this `TicTacToe` folder.
3. Let Gradle sync (Android Studio will auto-download the Gradle wrapper —
   no manual setup needed).
4. Press **Run ▶** with an emulator or a physical device connected.

Minimum supported Android version: **8.0 (API 26)**.

## Project structure

```
TicTacToe/
├── app/
│   ├── build.gradle.kts          # app dependencies, minSdk/targetSdk
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/tictactoe/
│       │   ├── MainActivity.kt   # game logic, score tracking
│       │   └── GameBoardView.kt  # custom-drawn chalk board/marks
│       └── res/
│           ├── layout/activity_main.xml
│           └── values/ (colors, strings, theme)
└── build.gradle.kts / settings.gradle.kts
```

## Turning on real Facebook/Meta ads

The app currently shows a placeholder ad slot (dark box labeled "Ad") sized
320×60dp — the standard Audience Network banner size — so a real ad drops
in without shifting the layout.

To go live:

1. Create an app at [developers.facebook.com/apps](https://developers.facebook.com/apps),
   enable **Audience Network**, and generate a banner **Placement ID**.
2. In `app/build.gradle.kts`, uncomment:
   ```kotlin
   implementation("com.facebook.android:audience-network-sdk:6.+")
   ```
   and in `settings.gradle.kts`, uncomment the Meta maven repository.
3. In `MainActivity.onCreate()`, replace the ad-slot comment block with:
   ```kotlin
   val adSlot = findViewById<FrameLayout>(R.id.adSlot)
   val adView = AdView(this, "YOUR_PLACEMENT_ID", AdSize.BANNER_HEIGHT_50)
   adSlot.removeAllViews()
   adSlot.addView(adView)
   adView.loadAd()
   ```
4. Add your Facebook App ID to `AndroidManifest.xml` per Meta's setup docs.

## Building an APK from your phone (no computer needed)

This project includes a GitHub Actions workflow (`.github/workflows/build-apk.yml`)
that compiles a real, installable APK in the cloud — you only need your phone's
browser.

1. Go to **github.com** in your phone browser and sign in (or create a free account).
2. Tap **+ → New repository**, name it (e.g. `tic-tac-toe-android`), keep it Public, create it.
3. On the new repo page, tap **Add file → Upload files**.
4. From your phone's file manager, select every file/folder from this unzipped
   `TicTacToe` folder (including the hidden `.github` folder — you may need to
   unzip with an app that shows hidden files, like ZArchiver, to see it) and
   upload them. Commit the upload.
5. Tap the **Actions** tab at the top of the repo. You'll see "Build APK"
   running automatically. Wait 2–3 minutes for it to finish (green check).
6. Tap into the finished run, scroll to **Artifacts**, and download
   `TicTacToe-debug-apk` — it's a zip containing `app-debug.apk`.
7. Unzip that on your phone, tap `app-debug.apk` to install (you may need to
   allow "install unknown apps" for your browser/file manager in Android
   Settings), and you're done.

If step 4's upload is finicky in your mobile browser, switch the browser to
"Desktop site" mode first — GitHub's drag-and-drop uploader handles nested
folders more reliably that way.

## Notes

- Two-player local play (X and O share the device, taking turns).
- Score persists only for the current app session (resets on app close).
- The board and marks are hand-drawn with `Canvas` in `GameBoardView.kt` —
  no image assets required.
