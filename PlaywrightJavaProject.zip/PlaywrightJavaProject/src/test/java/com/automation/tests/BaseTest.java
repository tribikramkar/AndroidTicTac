package com.automation.tests;

import com.automation.database.DatabaseManager;
import com.automation.database.DatabaseUtils;
import com.automation.database.SqlQueryExecutor;
import com.automation.driver.DriverManager;
import com.automation.listeners.TestListener;
import com.automation.pages.PowerBIDashboardPage;
import com.automation.reporting.ReportUtils;
import com.automation.validation.DataComparator;
import com.automation.utils.ScreenshotUtils;
import com.microsoft.playwright.Page;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;

import java.lang.reflect.Method;

/**
 * Base class for all integration tests.
 *
 * <p>Handles browser initialization, page object creation, database utility
 * setup, and reliable teardown. Subclasses access shared objects via protected fields.
 *
 * <p>The {@link TestListener} is registered here so all subclasses automatically
 * benefit from reporting and failure artifact capture.
 */
@Listeners(TestListener.class)
public abstract class BaseTest {

    protected final Logger log = LogManager.getLogger(getClass());

    protected Page page;
    protected PowerBIDashboardPage dashboardPage;
    protected DatabaseUtils databaseUtils;
    protected DataComparator dataComparator;

    @BeforeMethod(alwaysRun = true)
    public void setUp(Method method) {
        log.info("=== Setting up test: {} ===", method.getName());

        // Initialize browser
        DriverManager.initialize();
        page = DriverManager.getPage();

        // Initialize page objects
        dashboardPage = new PowerBIDashboardPage(page);

        // Initialize database utilities
        DatabaseManager dbManager = new DatabaseManager();
        SqlQueryExecutor executor = new SqlQueryExecutor(dbManager);
        databaseUtils = new DatabaseUtils(executor);

        // Initialize comparison engine
        dataComparator = new DataComparator();

        ReportUtils.logStep("Test setup complete. Browser and database utilities initialized.");
        log.info("Test setup complete.");
    }

    protected String takeScreenshot(String name) {
        return ScreenshotUtils.capture(page, name);
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(Method method) {
        log.info("=== Tearing down test: {} ===", method.getName());
        try {
            DriverManager.close();
        } catch (Exception e) {
            log.warn("Error during browser teardown: {}", e.getMessage());
        }
        log.info("Test teardown complete.");
    }
}
