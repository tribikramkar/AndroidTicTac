package com.automation.tests;

import com.automation.config.ConfigManager;
import com.automation.config.ConfigurationValidator;
import com.automation.models.ComparisonConfig;
import com.automation.models.ValidationResult;
import com.automation.reporting.ReportUtils;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

/**
 * End-to-end Power BI dashboard validation test.
 *
 * <p>This test demonstrates the complete framework flow:
 * <ol>
 *   <li>Validate integration configuration is present.</li>
 *   <li>Open the Power BI dashboard.</li>
 *   <li>Navigate to the configured report page and visual.</li>
 *   <li>Extract dashboard data via {@code PowerBIDashboardPage}.</li>
 *   <li>Execute the corresponding SQL query against SQL Server.</li>
 *   <li>Compare datasets using {@code DataComparator}.</li>
 *   <li>Log results to ExtentReports and Log4j2.</li>
 *   <li>Assert the validation passed.</li>
 * </ol>
 *
 * <p><strong>Prerequisites before running this test:</strong>
 * <ul>
 *   <li>Set all required properties in {@code config.properties} or as environment variables.
 *       See {@code .env.example} for the full list.</li>
 *   <li>Configure {@code browser.storage.state.path} with a saved Microsoft SSO session,
 *       or run headed ({@code browser.headless=false}) and authenticate manually.</li>
 *   <li>Replace the placeholder selectors in {@code PowerBIDashboardPage} with selectors
 *       validated against your actual Power BI report DOM.</li>
 *   <li>Replace {@code sql/powerbi_validation.sql} with your actual validation query.</li>
 *   <li>Update the {@code ComparisonConfig} below to match your column names and business keys.</li>
 * </ul>
 *
 * <p>Run unit tests independently with: {@code mvn clean test -Dtest=DataComparatorTest}
 */
public class PowerBIDashboardValidationTest extends BaseTest {

    private ConfigManager config;

    @BeforeClass
    public void validateConfiguration() {
        config = ConfigManager.getInstance();
        try {
            ConfigurationValidator.validateIntegrationConfig();
        } catch (Exception e) {
            throw new SkipException(
                    "Integration configuration is incomplete. Skipping integration test. " +
                    "Configure all required properties and re-run. Details: " + e.getMessage());
        }
    }

    @Test(description = "Validate Power BI dashboard data against SQL Server database")
    public void validatePowerBIDashboardAgainstDatabase() {

        // --- Step 1: Open dashboard ---
        ReportUtils.logStep("Opening Power BI dashboard: " + config.getDashboardUrl());
        dashboardPage.openDashboard();

        // --- Step 2: Navigate to report page ---
        ReportUtils.logStep("Navigating to report page: " + config.getPageName());
        dashboardPage.navigateToPage(config.getPageName());

        // --- Step 3: Select and wait for visual ---
        ReportUtils.logStep("Selecting visual: " + config.getVisualId());
        dashboardPage.selectVisual(config.getVisualId());
        dashboardPage.waitForVisualReady();

        // --- Step 4: Extract UI data ---
        ReportUtils.logStep("Extracting visual data from dashboard.");
        List<Map<String, Object>> uiData = dashboardPage.extractVisualData();
        ReportUtils.logInfo("UI rows extracted: " + uiData.size());

        // --- Step 5: Execute SQL query ---
        ReportUtils.logStep("Executing SQL query: sql/powerbi_validation.sql");
        List<Map<String, Object>> dbData = databaseUtils.executeQuery(
                "sql/powerbi_validation.sql"
                // Add query parameters here if your SQL uses ? placeholders:
                // , "parameterValue1", "parameterValue2"
        );
        ReportUtils.logInfo("DB rows returned: " + dbData.size());

        // --- Step 6: Build comparison configuration ---
        // TODO: Replace "YourKeyColumn", "YourMetricColumn1", etc. with your actual column names.
        // The business key must uniquely identify each row in both datasets.
        // columnMapping maps DB column names to their corresponding UI column names.
        ComparisonConfig comparisonConfig = ComparisonConfig.builder()
                .businessKey("YourKeyColumn")           // Replace with your actual key column
                .columnMapping("YourMetricColumn1", "MetricColumn1")  // DB col -> UI col
                .columnMapping("YourMetricColumn2", "MetricColumn2")
                .ignoreColumn("LastUpdated")            // Columns to skip in comparison
                .decimalTolerance(0.01)                 // Tolerance for numeric comparisons
                .normalizeWhitespace(true)
                .caseSensitive(false)
                .normalizeDates(true)
                .dateFormat("yyyy-MM-dd")
                .timezone("UTC")
                .validateRowCount(true)
                .build();

        // --- Step 7: Compare datasets ---
        ReportUtils.logStep("Comparing UI data against DB data.");
        ValidationResult result = dataComparator.compare(dbData, uiData, comparisonConfig);

        // --- Step 8: Log results ---
        ReportUtils.logValidationResult(result);

        // --- Step 9: Assert ---
        Assert.assertTrue(result.isPassed(), result.getSummary());
    }
}
