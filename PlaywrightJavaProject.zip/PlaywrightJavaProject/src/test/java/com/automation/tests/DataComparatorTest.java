package com.automation.tests;

import com.automation.models.ComparisonConfig;
import com.automation.models.FieldMismatch;
import com.automation.models.ValidationResult;
import com.automation.validation.DataComparator;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Unit tests for {@link DataComparator}.
 *
 * <p>No Playwright, SQL Server, credentials, or network access required.
 * All test data is constructed inline.
 */
public class DataComparatorTest {

    private DataComparator comparator;

    private static final ComparisonConfig DEFAULT_CONFIG = ComparisonConfig.builder()
            .businessKey("id")
            .normalizeWhitespace(true)
            .caseSensitive(false)
            .normalizeDates(true)
            .dateFormat("yyyy-MM-dd")
            .timezone("UTC")
            .validateRowCount(true)
            .build();

    @BeforeClass
    public void setUp() {
        comparator = new DataComparator();
    }

    // -------------------------------------------------------------------------
    // 1. Identical datasets
    // -------------------------------------------------------------------------

    @Test
    public void identicalDatasets_shouldPass() {
        List<Map<String, Object>> db = List.of(row("id", "1", "name", "Alice", "score", "100"));
        List<Map<String, Object>> ui = List.of(row("id", "1", "name", "Alice", "score", "100"));

        ValidationResult result = comparator.compare(db, ui, DEFAULT_CONFIG);

        Assert.assertTrue(result.isPassed());
        Assert.assertEquals(result.getMatchedRowCount(), 1);
        Assert.assertTrue(result.getMismatches().isEmpty());
    }

    // -------------------------------------------------------------------------
    // 2. Different row counts
    // -------------------------------------------------------------------------

    @Test
    public void differentRowCounts_shouldFail() {
        List<Map<String, Object>> db = List.of(
                row("id", "1", "name", "Alice"),
                row("id", "2", "name", "Bob"));
        List<Map<String, Object>> ui = List.of(
                row("id", "1", "name", "Alice"));

        ValidationResult result = comparator.compare(db, ui, DEFAULT_CONFIG);

        Assert.assertFalse(result.isPassed());
        Assert.assertEquals(result.getDbRowCount(), 2);
        Assert.assertEquals(result.getUiRowCount(), 1);
    }

    // -------------------------------------------------------------------------
    // 3. Missing UI records
    // -------------------------------------------------------------------------

    @Test
    public void missingUiRecord_shouldFail() {
        List<Map<String, Object>> db = List.of(
                row("id", "1", "name", "Alice"),
                row("id", "2", "name", "Bob"));
        List<Map<String, Object>> ui = List.of(
                row("id", "1", "name", "Alice"));

        ComparisonConfig config = ComparisonConfig.builder()
                .businessKey("id").validateRowCount(false).build();

        ValidationResult result = comparator.compare(db, ui, config);

        Assert.assertFalse(result.isPassed());
        Assert.assertEquals(result.getMissingInUiCount(), 1);
        Assert.assertTrue(result.getMissingInUiKeys().contains("2"));
    }

    // -------------------------------------------------------------------------
    // 4. Missing DB records
    // -------------------------------------------------------------------------

    @Test
    public void missingDbRecord_shouldFail() {
        List<Map<String, Object>> db = List.of(
                row("id", "1", "name", "Alice"));
        List<Map<String, Object>> ui = List.of(
                row("id", "1", "name", "Alice"),
                row("id", "2", "name", "Bob"));

        ComparisonConfig config = ComparisonConfig.builder()
                .businessKey("id").validateRowCount(false).build();

        ValidationResult result = comparator.compare(db, ui, config);

        Assert.assertFalse(result.isPassed());
        Assert.assertEquals(result.getMissingInDbCount(), 1);
        Assert.assertTrue(result.getMissingInDbKeys().contains("2"));
    }

    // -------------------------------------------------------------------------
    // 5. Incorrect field values
    // -------------------------------------------------------------------------

    @Test
    public void incorrectFieldValue_shouldFail() {
        List<Map<String, Object>> db = List.of(row("id", "1", "amount", "100.00"));
        List<Map<String, Object>> ui = List.of(row("id", "1", "amount", "99.00"));

        ValidationResult result = comparator.compare(db, ui, DEFAULT_CONFIG);

        Assert.assertFalse(result.isPassed());
        Assert.assertEquals(result.getMismatches().size(), 1);
        FieldMismatch m = result.getMismatches().get(0);
        Assert.assertEquals(m.getColumnName(), "amount");
        Assert.assertEquals(m.getExpectedValue(), "100.00");
        Assert.assertEquals(m.getActualValue(), "99.00");
    }

    // -------------------------------------------------------------------------
    // 6. Null vs null
    // -------------------------------------------------------------------------

    @Test
    public void nullVsNull_shouldPass() {
        List<Map<String, Object>> db = List.of(rowWithNull("id", "1", "value"));
        List<Map<String, Object>> ui = List.of(rowWithNull("id", "1", "value"));

        ValidationResult result = comparator.compare(db, ui, DEFAULT_CONFIG);

        Assert.assertTrue(result.isPassed());
    }

    // -------------------------------------------------------------------------
    // 7. Null vs empty string (default: not equal)
    // -------------------------------------------------------------------------

    @Test
    public void nullVsEmptyString_defaultConfig_shouldFail() {
        List<Map<String, Object>> db = List.of(rowWithNull("id", "1", "value"));
        Map<String, Object> uiRow = new LinkedHashMap<>();
        uiRow.put("id", "1");
        uiRow.put("value", "");
        List<Map<String, Object>> ui = List.of(uiRow);

        ValidationResult result = comparator.compare(db, ui, DEFAULT_CONFIG);

        Assert.assertFalse(result.isPassed());
    }

    // -------------------------------------------------------------------------
    // 8. Null vs empty string (treatNullAsEmpty: equal)
    // -------------------------------------------------------------------------

    @Test
    public void nullVsEmptyString_treatNullAsEmpty_shouldPass() {
        List<Map<String, Object>> db = List.of(rowWithNull("id", "1", "value"));
        Map<String, Object> uiRow = new LinkedHashMap<>();
        uiRow.put("id", "1");
        uiRow.put("value", "");
        List<Map<String, Object>> ui = List.of(uiRow);

        ComparisonConfig config = ComparisonConfig.builder()
                .businessKey("id").treatNullAsEmpty(true).build();

        ValidationResult result = comparator.compare(db, ui, config);

        Assert.assertTrue(result.isPassed());
    }

    // -------------------------------------------------------------------------
    // 9. Numeric values with different representations
    // -------------------------------------------------------------------------

    @Test
    public void numericDifferentRepresentations_shouldPass() {
        List<Map<String, Object>> db = List.of(row("id", "1", "amount", "100"));
        List<Map<String, Object>> ui = List.of(row("id", "1", "amount", "100.00"));

        // Both normalize to "100" via BigDecimal.stripTrailingZeros
        ValidationResult result = comparator.compare(db, ui, DEFAULT_CONFIG);

        Assert.assertTrue(result.isPassed(), result.getSummary());
    }

    // -------------------------------------------------------------------------
    // 10. Decimal tolerance
    // -------------------------------------------------------------------------

    @Test
    public void decimalTolerance_withinTolerance_shouldPass() {
        List<Map<String, Object>> db = List.of(row("id", "1", "rate", "10.005"));
        List<Map<String, Object>> ui = List.of(row("id", "1", "rate", "10.004"));

        ComparisonConfig config = ComparisonConfig.builder()
                .businessKey("id").decimalTolerance(0.01).build();

        ValidationResult result = comparator.compare(db, ui, config);

        Assert.assertTrue(result.isPassed());
    }

    @Test
    public void decimalTolerance_outsideTolerance_shouldFail() {
        List<Map<String, Object>> db = List.of(row("id", "1", "rate", "10.00"));
        List<Map<String, Object>> ui = List.of(row("id", "1", "rate", "10.05"));

        ComparisonConfig config = ComparisonConfig.builder()
                .businessKey("id").decimalTolerance(0.01).build();

        ValidationResult result = comparator.compare(db, ui, config);

        Assert.assertFalse(result.isPassed());
    }

    // -------------------------------------------------------------------------
    // 11. Date format normalization
    // -------------------------------------------------------------------------

    @Test
    public void dateNormalization_differentFormats_shouldPass() {
        Map<String, Object> dbRow = new LinkedHashMap<>();
        dbRow.put("id", "1");
        dbRow.put("orderDate", java.sql.Date.valueOf("2024-01-15"));

        Map<String, Object> uiRow = new LinkedHashMap<>();
        uiRow.put("id", "1");
        uiRow.put("orderDate", "2024-01-15");

        ValidationResult result = comparator.compare(List.of(dbRow), List.of(uiRow), DEFAULT_CONFIG);

        Assert.assertTrue(result.isPassed(), result.getSummary());
    }

    // -------------------------------------------------------------------------
    // 12. Timestamp and timezone handling
    // -------------------------------------------------------------------------

    @Test
    public void timestampNormalization_shouldNormalizeToConfiguredTimezone() {
        Timestamp ts = Timestamp.valueOf(LocalDateTime.of(2024, 1, 15, 12, 0, 0));

        Map<String, Object> dbRow = new LinkedHashMap<>();
        dbRow.put("id", "1");
        dbRow.put("createdAt", ts);

        Map<String, Object> uiRow = new LinkedHashMap<>();
        uiRow.put("id", "1");
        uiRow.put("createdAt", "2024-01-15");

        ComparisonConfig config = ComparisonConfig.builder()
                .businessKey("id")
                .normalizeDates(true)
                .dateFormat("yyyy-MM-dd")
                .timezone("UTC")
                .build();

        ValidationResult result = comparator.compare(List.of(dbRow), List.of(uiRow), config);

        Assert.assertTrue(result.isPassed(), result.getSummary());
    }

    // -------------------------------------------------------------------------
    // 13. UI-to-DB column mappings
    // -------------------------------------------------------------------------

    @Test
    public void columnMapping_differentColumnNames_shouldPass() {
        List<Map<String, Object>> db = List.of(row("order_id", "1", "total_amount", "500.00"));
        List<Map<String, Object>> ui = List.of(row("order_id", "1", "TotalAmount", "500.00"));

        ComparisonConfig config = ComparisonConfig.builder()
                .businessKey("order_id")
                .columnMapping("total_amount", "TotalAmount")
                .build();

        ValidationResult result = comparator.compare(db, ui, config);

        Assert.assertTrue(result.isPassed(), result.getSummary());
    }

    // -------------------------------------------------------------------------
    // 14. Case-insensitive comparison
    // -------------------------------------------------------------------------

    @Test
    public void caseInsensitiveComparison_shouldPass() {
        List<Map<String, Object>> db = List.of(row("id", "1", "status", "ACTIVE"));
        List<Map<String, Object>> ui = List.of(row("id", "1", "status", "active"));

        ComparisonConfig config = ComparisonConfig.builder()
                .businessKey("id").caseSensitive(false).build();

        ValidationResult result = comparator.compare(db, ui, config);

        Assert.assertTrue(result.isPassed());
    }

    @Test
    public void caseSensitiveComparison_differentCase_shouldFail() {
        List<Map<String, Object>> db = List.of(row("id", "1", "status", "ACTIVE"));
        List<Map<String, Object>> ui = List.of(row("id", "1", "status", "active"));

        ComparisonConfig config = ComparisonConfig.builder()
                .businessKey("id").caseSensitive(true).build();

        ValidationResult result = comparator.compare(db, ui, config);

        Assert.assertFalse(result.isPassed());
    }

    // -------------------------------------------------------------------------
    // 15. Whitespace normalization
    // -------------------------------------------------------------------------

    @Test
    public void whitespaceNormalization_shouldPass() {
        List<Map<String, Object>> db = List.of(row("id", "1", "name", "  Alice  "));
        List<Map<String, Object>> ui = List.of(row("id", "1", "name", "Alice"));

        ComparisonConfig config = ComparisonConfig.builder()
                .businessKey("id").normalizeWhitespace(true).build();

        ValidationResult result = comparator.compare(db, ui, config);

        Assert.assertTrue(result.isPassed());
    }

    // -------------------------------------------------------------------------
    // 16. Ignored columns
    // -------------------------------------------------------------------------

    @Test
    public void ignoredColumns_shouldNotAffectResult() {
        List<Map<String, Object>> db = List.of(row("id", "1", "name", "Alice", "lastUpdated", "2024-01-01"));
        List<Map<String, Object>> ui = List.of(row("id", "1", "name", "Alice", "lastUpdated", "2024-12-31"));

        ComparisonConfig config = ComparisonConfig.builder()
                .businessKey("id").ignoreColumn("lastUpdated").build();

        ValidationResult result = comparator.compare(db, ui, config);

        Assert.assertTrue(result.isPassed());
    }

    // -------------------------------------------------------------------------
    // 17. Unordered datasets matched by business key
    // -------------------------------------------------------------------------

    @Test
    public void unorderedDatasets_shouldMatchByKey() {
        List<Map<String, Object>> db = List.of(
                row("id", "2", "name", "Bob"),
                row("id", "1", "name", "Alice"),
                row("id", "3", "name", "Charlie"));
        List<Map<String, Object>> ui = List.of(
                row("id", "3", "name", "Charlie"),
                row("id", "1", "name", "Alice"),
                row("id", "2", "name", "Bob"));

        ValidationResult result = comparator.compare(db, ui, DEFAULT_CONFIG);

        Assert.assertTrue(result.isPassed());
        Assert.assertEquals(result.getMatchedRowCount(), 3);
    }

    // -------------------------------------------------------------------------
    // 18. Composite keys
    // -------------------------------------------------------------------------

    @Test
    public void compositeKeys_shouldMatchCorrectly() {
        List<Map<String, Object>> db = List.of(
                row("region", "US", "product", "A", "sales", "1000"),
                row("region", "EU", "product", "A", "sales", "2000"));
        List<Map<String, Object>> ui = List.of(
                row("region", "EU", "product", "A", "sales", "2000"),
                row("region", "US", "product", "A", "sales", "1000"));

        ComparisonConfig config = ComparisonConfig.builder()
                .businessKeys(List.of("region", "product"))
                .build();

        ValidationResult result = comparator.compare(db, ui, config);

        Assert.assertTrue(result.isPassed());
    }

    // -------------------------------------------------------------------------
    // 19. Duplicate business keys
    // -------------------------------------------------------------------------

    @Test
    public void duplicateBusinessKeys_shouldFail() {
        List<Map<String, Object>> db = List.of(
                row("id", "1", "name", "Alice"),
                row("id", "1", "name", "Alice Duplicate"));
        List<Map<String, Object>> ui = List.of(
                row("id", "1", "name", "Alice"));

        ValidationResult result = comparator.compare(db, ui, DEFAULT_CONFIG);

        Assert.assertFalse(result.isPassed());
        Assert.assertTrue(result.getSummary().contains("Duplicate"));
    }

    // -------------------------------------------------------------------------
    // 20. Empty datasets
    // -------------------------------------------------------------------------

    @Test
    public void bothDatasetsEmpty_shouldPass() {
        ValidationResult result = comparator.compare(
                Collections.emptyList(), Collections.emptyList(), DEFAULT_CONFIG);

        Assert.assertTrue(result.isPassed());
    }

    @Test
    public void dbEmptyUiNotEmpty_shouldFail() {
        List<Map<String, Object>> ui = List.of(row("id", "1", "name", "Alice"));

        ValidationResult result = comparator.compare(Collections.emptyList(), ui, DEFAULT_CONFIG);

        Assert.assertFalse(result.isPassed());
    }

    @Test
    public void uiEmptyDbNotEmpty_shouldFail() {
        List<Map<String, Object>> db = List.of(row("id", "1", "name", "Alice"));

        ValidationResult result = comparator.compare(db, Collections.emptyList(), DEFAULT_CONFIG);

        Assert.assertFalse(result.isPassed());
    }

    // -------------------------------------------------------------------------
    // 21. Missing required columns (business key not in dataset)
    // -------------------------------------------------------------------------

    @Test(expectedExceptions = IllegalArgumentException.class)
    public void missingBusinessKeyColumn_shouldThrow() {
        List<Map<String, Object>> db = List.of(row("name", "Alice", "score", "100"));
        List<Map<String, Object>> ui = List.of(row("name", "Alice", "score", "100"));

        ComparisonConfig config = ComparisonConfig.builder()
                .businessKey("nonExistentKey").build();

        comparator.compare(db, ui, config);
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private Map<String, Object> row(Object... keyValues) {
        Map<String, Object> map = new LinkedHashMap<>();
        for (int i = 0; i < keyValues.length - 1; i += 2) {
            map.put(keyValues[i].toString(), keyValues[i + 1]);
        }
        return map;
    }

    private Map<String, Object> rowWithNull(String idKey, String idValue, String nullKey) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put(idKey, idValue);
        map.put(nullKey, null);
        return map;
    }
}
