package com.automation.tests;

import com.automation.config.ConfigManager;
import com.automation.reporting.ReportUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Smoke tests to verify the browser launches correctly and basic page
 * navigation works. No database or Power BI access required.
 */
public class BrowserSmokeTest extends BaseTest {

    @Test(description = "Verify browser opens and dashboard URL loads")
    public void browserOpens_andPageTitleIsCorrect() {
        String url = ConfigManager.getInstance().getDashboardUrl();
        ReportUtils.logStep("Navigating to: " + url);
        page.navigate(url);

        String title = page.title();
        log.info("Page title: {}", title);
        ReportUtils.logInfo("Page title: " + title);

        Assert.assertFalse(title.isBlank(), "Page title should not be blank");
        ReportUtils.logPass("Browser opened successfully. Title: " + title);
    }

    @Test(description = "Verify page URL matches the configured dashboard URL")
    public void browserNavigates_andUrlIsCorrect() {
        String targetUrl = ConfigManager.getInstance().getDashboardUrl();
        ReportUtils.logStep("Navigating to: " + targetUrl);
        page.navigate(targetUrl);

        String currentUrl = page.url();
        log.info("Current URL: {}", currentUrl);
        ReportUtils.logInfo("Current URL: " + currentUrl);

        Assert.assertNotNull(currentUrl, "Current URL should not be null");
        Assert.assertFalse(currentUrl.isBlank(), "Current URL should not be blank");
        ReportUtils.logPass("Navigation successful. URL: " + currentUrl);
    }

    @Test(description = "Verify screenshot capture works on the dashboard URL")
    public void screenshotCapture_shouldSaveFile() {
        String url = ConfigManager.getInstance().getDashboardUrl();
        ReportUtils.logStep("Navigating to: " + url);
        page.navigate(url);

        String screenshotPath = takeScreenshot("smoke_test_screenshot");

        Assert.assertNotNull(screenshotPath, "Screenshot path should not be null");
        Assert.assertTrue(new java.io.File(screenshotPath).exists(),
                "Screenshot file should exist at: " + screenshotPath);

        ReportUtils.logPass("Screenshot saved at: " + screenshotPath);
        ReportUtils.attachScreenshot(screenshotPath);
    }
}
