package com.automation.listeners;

import com.automation.driver.DriverManager;
import com.automation.reporting.ExtentReportManager;
import com.automation.reporting.ReportUtils;
import com.automation.utils.ScreenshotUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.*;

/**
 * TestNG listener that manages the ExtentReports lifecycle and captures
 * failure artifacts (screenshots, stack traces).
 *
 * <p>Register this listener in testng.xml or via {@code @Listeners} on BaseTest.
 */
public class TestListener implements ITestListener, ISuiteListener, IConfigurationListener {

    private static final Logger log = LogManager.getLogger(TestListener.class);

    // -------------------------------------------------------------------------
    // ISuiteListener
    // -------------------------------------------------------------------------

    @Override
    public void onStart(ISuite suite) {
        log.info("=== Suite started: {} ===", suite.getName());
        ExtentReportManager.initReports();
    }

    @Override
    public void onFinish(ISuite suite) {
        log.info("=== Suite finished: {} ===", suite.getName());
        ExtentReportManager.flush();
    }

    // -------------------------------------------------------------------------
    // ITestListener
    // -------------------------------------------------------------------------

    @Override
    public void onTestStart(ITestResult result) {
        String testName = getTestName(result);
        log.info("--- Test started: {} ---", testName);
        ExtentReportManager.createTest(testName, getDescription(result));
        ReportUtils.logStep("Test started: " + testName);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        String testName = getTestName(result);
        long durationMs = result.getEndMillis() - result.getStartMillis();
        log.info("--- Test PASSED: {} ({} ms) ---", testName, durationMs);
        ReportUtils.logPass("Test passed in " + durationMs + " ms.");
        ExtentReportManager.removeTest();
    }

    @Override
    public void onTestFailure(ITestResult result) {
        String testName = getTestName(result);
        long durationMs = result.getEndMillis() - result.getStartMillis();
        log.error("--- Test FAILED: {} ({} ms) ---", testName, durationMs);

        Throwable throwable = result.getThrowable();
        if (throwable != null) {
            ReportUtils.logFail("Test failed: " + throwable.getMessage(), throwable);
        } else {
            ReportUtils.logFail("Test failed with no exception details.");
        }

        // Capture screenshot on failure
        try {
            String screenshotPath = ScreenshotUtils.capture(DriverManager.getPage(), testName + "_FAILURE");
            if (screenshotPath != null) {
                ReportUtils.attachScreenshot(screenshotPath);
            }
        } catch (Exception e) {
            log.warn("Could not capture failure screenshot: {}", e.getMessage());
        }

        // Save trace on failure
        try {
            DriverManager.saveTrace(testName);
        } catch (Exception e) {
            log.warn("Could not save trace: {}", e.getMessage());
        }

        ExtentReportManager.removeTest();
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        String testName = getTestName(result);
        log.warn("--- Test SKIPPED: {} ---", testName);
        ReportUtils.logSkip("Test skipped: " + (result.getThrowable() != null
                ? result.getThrowable().getMessage() : "no reason provided"));
        ExtentReportManager.removeTest();
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        log.warn("Test failed within success percentage: {}", getTestName(result));
    }

    @Override
    public void onConfigurationFailure(ITestResult result) {
        String testName = getTestName(result);
        log.error("Configuration method failed: {}", testName);
        Throwable throwable = result.getThrowable();
        if (throwable != null) {
            log.error("Configuration failure cause: {}", throwable.getMessage(), throwable);
        }
        ReportUtils.logFail("Configuration failed: " + testName +
                (throwable != null ? " — " + throwable.getMessage() : ""));
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private String getTestName(ITestResult result) {
        return result.getTestClass().getName() + "." + result.getMethod().getMethodName();
    }

    private String getDescription(ITestResult result) {
        String desc = result.getMethod().getDescription();
        return (desc != null && !desc.isBlank()) ? desc : "";
    }
}
