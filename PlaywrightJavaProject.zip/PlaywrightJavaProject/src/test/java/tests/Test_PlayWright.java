package tests;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class Test_PlayWright {

    public static void main(String[] args) {
        try {

            Playwright playwright = Playwright.create();
            Browser browser=playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false).setSlowMo(1000));
            Page page=browser.newPage();
            page.navigate("https://playwright.dev/java/");
            String title=page.title();
            System.out.println(title);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
