package com.automation.exceptions;

/**
 * Thrown when a browser page interaction fails.
 */
public class PageException extends RuntimeException {

    public PageException(String message) {
        super(message);
    }

    public PageException(String message, Throwable cause) {
        super(message, cause);
    }
}
