package com.automation.exceptions;

/**
 * Thrown when data extraction from a UI visual fails or returns incomplete data.
 */
public class DataExtractionException extends RuntimeException {

    public DataExtractionException(String message) {
        super(message);
    }

    public DataExtractionException(String message, Throwable cause) {
        super(message, cause);
    }
}
