package com.automation.exceptions;

/**
 * Thrown when required configuration properties are missing or invalid.
 */
public class ConfigurationException extends RuntimeException {

    public ConfigurationException(String message) {
        super(message);
    }

    public ConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }
}
