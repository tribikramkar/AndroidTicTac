package com.automation.driver;

import com.automation.config.ConfigManager;
import com.automation.exceptions.ConfigurationException;
import com.microsoft.playwright.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 * Manages the Playwright, Browser, and BrowserContext lifecycle for a single test.
 *
 * <p>Each test should create its own {@code PlaywrightFactory} instance to ensure
 * full isolation and safe future parallel execution.
 *
 * <p><strong>Authentication note:</strong> Power BI requires Microsoft SSO/MFA.
 * The framework supports two approaches:
 * <ul>
 *   <li><strong>Saved storage state</strong> – authenticate once manually, save
 *       browser storage state to a file, and supply the path via
 *       {@code browser.storage.state.path} in config.properties. The context will
 *       be initialized with that state on every test run.</li>
 *   <li><strong>Interactive headed run</strong> – set {@code browser.headless=false}
 *       and handle the SSO prompt manually during the first run.</li>
 * </ul>
 * Never bypass, disable, or circumvent company authentication or MFA policies.
 */
public class PlaywrightFactory implements AutoCloseable {

    private static final Logger log = LogManager.getLogger(PlaywrightFactory.class);

    private final ConfigManager config;
    private Playwright playwright;
    private Browser browser;
    private BrowserContext context;
    private Page page;

    public PlaywrightFactory() {
        this.config = ConfigManager.getInstance();
    }

    /**
     * Initializes Playwright, launches the configured browser, creates a
     * BrowserContext and Page, and configures default timeouts.
     *
     * @return the ready-to-use {@link Page}
     */
    public Page initialize() {
        log.info("Initializing Playwright. Browser: {}, Headless: {}",
                config.getBrowserType(), config.isHeadless());

        playwright = Playwright.create();
        browser = launchBrowser();
        context = createContext();
        page = context.newPage();

        page.setDefaultTimeout(config.getBrowserTimeoutMs());
        page.setDefaultNavigationTimeout(config.getNavigationTimeoutMs());

        if (config.isTracingEnabled()) {
            context.tracing().start(new Tracing.StartOptions()
                    .setScreenshots(true)
                    .setSnapshots(true)
                    .setSources(false));
            log.debug("Playwright tracing started.");
        }

        log.info("Browser initialized successfully.");
        return page;
    }

    private Browser launchBrowser() {
        BrowserType.LaunchOptions options = new BrowserType.LaunchOptions()
                .setHeadless(config.isHeadless());

        // If a custom executable path is configured, use it (e.g. system Chrome)
        String executablePath = config.get("browser.executable.path");
        if (executablePath != null && !executablePath.isBlank()) {
            options.setExecutablePath(java.nio.file.Paths.get(executablePath));
            log.info("Using custom browser executable: {}", executablePath);
        }

        return switch (config.getBrowserType().toLowerCase()) {
            case "firefox"                    -> playwright.firefox().launch(options);
            case "webkit", "safari"           -> playwright.webkit().launch(options);
            case "chromium", "chrome", "edge" -> playwright.chromium().launch(options);
            default -> throw new ConfigurationException(
                    "Unsupported browser type: '" + config.getBrowserType() +
                    "'. Supported values: chromium, chrome, edge, firefox, webkit, safari.");
        };
    }

    private BrowserContext createContext() {
        Browser.NewContextOptions contextOptions = new Browser.NewContextOptions()
                .setViewportSize(config.getViewportWidth(), config.getViewportHeight());

        String storageStatePath = config.get("browser.storage.state.path");
        if (storageStatePath != null && !storageStatePath.isBlank()) {
            Path statePath = Paths.get(storageStatePath);
            if (statePath.toFile().exists()) {
                contextOptions.setStorageStatePath(statePath);
                log.info("Loaded browser storage state from: {}", storageStatePath);
            } else {
                log.warn("Storage state file not found at '{}'. Starting with a fresh context.", storageStatePath);
            }
        }

        return browser.newContext(contextOptions);
    }

    /**
     * Saves a Playwright trace to the configured trace directory.
     * Call this on test failure when tracing is enabled.
     *
     * @param testName used to build the trace filename
     */
    public void saveTrace(String testName) {
        if (!config.isTracingEnabled() || context == null) return;
        try {
            String safeName = testName.replaceAll("[^a-zA-Z0-9_\\-]", "_");
            Path tracePath = Paths.get(config.getTraceDir(),
                    safeName + "_" + System.currentTimeMillis() + ".zip");
            context.tracing().stop(new Tracing.StopOptions().setPath(tracePath));
            log.info("Trace saved to: {}", tracePath.toAbsolutePath());
        } catch (Exception e) {
            log.warn("Failed to save trace: {}", e.getMessage());
        }
    }

    /**
     * Closes Page, BrowserContext, Browser, and Playwright in the correct order.
     * Safe to call even if initialization was partial.
     */
    @Override
    public void close() {
        log.debug("Closing browser resources.");
        closeQuietly(page,       "Page");
        closeQuietly(context,    "BrowserContext");
        closeQuietly(browser,    "Browser");
        closeQuietly(playwright, "Playwright");
        log.info("Browser resources closed.");
    }

    private void closeQuietly(AutoCloseable resource, String name) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                log.warn("Error closing {}: {}", name, e.getMessage());
            }
        }
    }

    public Page getPage()               { return page; }
    public Browser getBrowser()         { return browser; }
    public BrowserContext getContext()  { return context; }
    public Playwright getPlaywright()   { return playwright; }
}
