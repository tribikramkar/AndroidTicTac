package com.automation.driver;

import com.microsoft.playwright.Page;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Provides thread-local access to the current test's {@link PlaywrightFactory} and {@link Page}.
 *
 * <p>Each test thread holds its own factory instance, enabling safe parallel execution.
 * {@link #initialize()} must be called before any page access, and {@link #close()}
 * must be called in the test teardown to release all browser resources.
 */
public final class DriverManager {

    private static final Logger log = LogManager.getLogger(DriverManager.class);

    private static final ThreadLocal<PlaywrightFactory> factoryHolder = new ThreadLocal<>();
    private static final ThreadLocal<Page> pageHolder = new ThreadLocal<>();

    private DriverManager() {}

    /**
     * Creates a new {@link PlaywrightFactory} for the current thread, initializes
     * the browser, and stores the resulting {@link Page} in thread-local storage.
     */
    public static void initialize() {
        PlaywrightFactory factory = new PlaywrightFactory();
        Page page = factory.initialize();
        factoryHolder.set(factory);
        pageHolder.set(page);
        log.debug("DriverManager initialized for thread: {}", Thread.currentThread().getName());
    }

    /**
     * Returns the {@link Page} for the current thread.
     *
     * @throws IllegalStateException if {@link #initialize()} has not been called
     */
    public static Page getPage() {
        Page page = pageHolder.get();
        if (page == null) {
            throw new IllegalStateException(
                    "Page is not initialized. Call DriverManager.initialize() before accessing the page.");
        }
        return page;
    }

    /**
     * Returns the {@link PlaywrightFactory} for the current thread.
     *
     * @throws IllegalStateException if {@link #initialize()} has not been called
     */
    public static PlaywrightFactory getFactory() {
        PlaywrightFactory factory = factoryHolder.get();
        if (factory == null) {
            throw new IllegalStateException(
                    "PlaywrightFactory is not initialized. Call DriverManager.initialize() first.");
        }
        return factory;
    }

    /**
     * Saves a trace for the current test (no-op if tracing is disabled).
     *
     * @param testName used to build the trace filename
     */
    public static void saveTrace(String testName) {
        PlaywrightFactory factory = factoryHolder.get();
        if (factory != null) {
            factory.saveTrace(testName);
        }
    }

    /**
     * Closes all browser resources for the current thread and removes thread-local references.
     */
    public static void close() {
        PlaywrightFactory factory = factoryHolder.get();
        if (factory != null) {
            try {
                factory.close();
            } finally {
                factoryHolder.remove();
                pageHolder.remove();
                log.debug("DriverManager closed for thread: {}", Thread.currentThread().getName());
            }
        }
    }
}
