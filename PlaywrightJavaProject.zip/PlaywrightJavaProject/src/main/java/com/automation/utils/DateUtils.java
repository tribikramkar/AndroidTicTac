package com.automation.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

/**
 * Date and timestamp normalization utilities for cross-dataset comparison.
 */
public final class DateUtils {

    private static final Logger log = LogManager.getLogger(DateUtils.class);

    /** Common date/datetime formats tried during flexible parsing. */
    private static final List<DateTimeFormatter> COMMON_FORMATS = List.of(
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("MM/dd/yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"),
            DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss"),
            DateTimeFormatter.ISO_LOCAL_DATE,
            DateTimeFormatter.ISO_LOCAL_DATE_TIME
    );

    private DateUtils() {}

    /**
     * Parses a date string using the specified format.
     *
     * @param dateStr the date string
     * @param format  the expected format pattern
     * @return parsed {@link LocalDate}
     * @throws IllegalArgumentException if parsing fails
     */
    public static LocalDate parseDate(String dateStr, String format) {
        try {
            return LocalDate.parse(dateStr.trim(), DateTimeFormatter.ofPattern(format));
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException(
                    "Cannot parse date '" + dateStr + "' with format '" + format + "'", e);
        }
    }

    /**
     * Attempts to parse a date string using a list of common formats.
     *
     * @param dateStr the date string
     * @return parsed {@link LocalDate}, or {@code null} if no format matches
     */
    public static LocalDate parseDateFlexible(String dateStr) {
        if (dateStr == null || dateStr.isBlank()) return null;
        for (DateTimeFormatter fmt : COMMON_FORMATS) {
            try {
                return LocalDate.parse(dateStr.trim(), fmt);
            } catch (DateTimeParseException ignored) {}
        }
        log.warn("Could not parse date string '{}' with any known format.", dateStr);
        return null;
    }

    /**
     * Formats a {@link LocalDate} using the specified pattern.
     */
    public static String formatDate(LocalDate date, String format) {
        return date.format(DateTimeFormatter.ofPattern(format));
    }

    /**
     * Converts a date string from one format to another.
     *
     * @param dateStr    the input date string
     * @param fromFormat the current format
     * @param toFormat   the target format
     * @return reformatted date string
     */
    public static String reformat(String dateStr, String fromFormat, String toFormat) {
        LocalDate date = parseDate(dateStr, fromFormat);
        return formatDate(date, toFormat);
    }

    /**
     * Converts a {@link java.sql.Timestamp} to a formatted string in the specified timezone.
     *
     * @param timestamp the SQL timestamp
     * @param format    the output format pattern
     * @param timezone  the target timezone ID (e.g. "UTC", "America/New_York")
     * @return formatted timestamp string
     */
    public static String formatTimestamp(java.sql.Timestamp timestamp, String format, String timezone) {
        ZoneId zone = ZoneId.of(timezone);
        ZonedDateTime zdt = timestamp.toLocalDateTime()
                .atZone(ZoneId.systemDefault())
                .withZoneSameInstant(zone);
        return zdt.format(DateTimeFormatter.ofPattern(format));
    }

    /**
     * Returns true if two date strings represent the same date after normalization.
     *
     * @param date1  first date string
     * @param date2  second date string
     * @param format the expected format for both strings
     */
    public static boolean datesEqual(String date1, String date2, String format) {
        if (date1 == null && date2 == null) return true;
        if (date1 == null || date2 == null) return false;
        try {
            LocalDate d1 = parseDate(date1, format);
            LocalDate d2 = parseDate(date2, format);
            return d1.equals(d2);
        } catch (IllegalArgumentException e) {
            log.warn("Date comparison failed: {}", e.getMessage());
            return false;
        }
    }
}
