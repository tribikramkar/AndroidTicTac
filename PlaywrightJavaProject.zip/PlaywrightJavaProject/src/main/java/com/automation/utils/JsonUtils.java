package com.automation.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;

/**
 * Jackson-based JSON serialization, deserialization, and classpath resource loading.
 */
public final class JsonUtils {

    private static final Logger log = LogManager.getLogger(JsonUtils.class);

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

    private JsonUtils() {}

    /**
     * Deserializes a JSON classpath resource into the specified type.
     *
     * @param resourcePath classpath-relative path, e.g. {@code "testdata/comparison-test-data.json"}
     * @param typeRef      Jackson type reference for the target type
     * @return deserialized object
     * @throws RuntimeException if the resource is not found or cannot be parsed
     */
    public static <T> T loadResource(String resourcePath, TypeReference<T> typeRef) {
        try (InputStream is = JsonUtils.class.getClassLoader().getResourceAsStream(resourcePath)) {
            if (is == null) {
                throw new RuntimeException("JSON resource not found: '" + resourcePath + "'");
            }
            T result = MAPPER.readValue(is, typeRef);
            log.debug("Loaded JSON resource: {}", resourcePath);
            return result;
        } catch (IOException e) {
            throw new RuntimeException("Failed to parse JSON resource: " + resourcePath, e);
        }
    }

    /**
     * Deserializes a JSON string into the specified type.
     */
    public static <T> T fromJson(String json, TypeReference<T> typeRef) {
        try {
            return MAPPER.readValue(json, typeRef);
        } catch (IOException e) {
            throw new RuntimeException("Failed to deserialize JSON: " + e.getMessage(), e);
        }
    }

    /**
     * Serializes an object to a JSON string.
     */
    public static String toJson(Object object) {
        try {
            return MAPPER.writeValueAsString(object);
        } catch (IOException e) {
            throw new RuntimeException("Failed to serialize object to JSON: " + e.getMessage(), e);
        }
    }

    /**
     * Serializes an object to a pretty-printed JSON string.
     */
    public static String toPrettyJson(Object object) {
        try {
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(object);
        } catch (IOException e) {
            throw new RuntimeException("Failed to serialize object to JSON: " + e.getMessage(), e);
        }
    }

    public static ObjectMapper getMapper() {
        return MAPPER;
    }
}
