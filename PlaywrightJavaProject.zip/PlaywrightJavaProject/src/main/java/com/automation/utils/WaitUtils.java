package com.automation.utils;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Explicit Playwright wait helpers.
 *
 * <p>Never uses {@code Thread.sleep()}. All waits use Playwright's built-in
 * condition-based waiting mechanisms.
 */
public final class WaitUtils {

    private static final Logger log = LogManager.getLogger(WaitUtils.class);

    private WaitUtils() {}

    /**
     * Waits for a locator to be visible within the default page timeout.
     */
    public static void waitForVisible(Locator locator) {
        locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
    }

    /**
     * Waits for a locator to be visible within the specified timeout.
     *
     * @param timeoutMs timeout in milliseconds
     */
    public static void waitForVisible(Locator locator, double timeoutMs) {
        locator.waitFor(new Locator.WaitForOptions()
                .setState(WaitForSelectorState.VISIBLE)
                .setTimeout(timeoutMs));
    }

    /**
     * Waits for a locator to be hidden (not visible or detached from DOM).
     */
    public static void waitForHidden(Locator locator) {
        locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN));
    }

    /**
     * Waits for a locator to be hidden within the specified timeout.
     */
    public static void waitForHidden(Locator locator, double timeoutMs) {
        locator.waitFor(new Locator.WaitForOptions()
                .setState(WaitForSelectorState.HIDDEN)
                .setTimeout(timeoutMs));
    }

    /**
     * Waits for a locator to be attached to the DOM.
     */
    public static void waitForAttached(Locator locator) {
        locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.ATTACHED));
    }

    /**
     * Waits for the page network to reach an idle state.
     */
    public static void waitForNetworkIdle(Page page) {
        log.debug("Waiting for network idle...");
        page.waitForLoadState(com.microsoft.playwright.options.LoadState.NETWORKIDLE);
    }

    /**
     * Waits for the DOM content to be fully loaded.
     */
    public static void waitForDomContentLoaded(Page page) {
        page.waitForLoadState(com.microsoft.playwright.options.LoadState.DOMCONTENTLOADED);
    }

    /**
     * Waits for a JavaScript condition to return true.
     *
     * @param page      the Playwright page
     * @param jsCondition a JavaScript expression that evaluates to a boolean
     */
    public static void waitForCondition(Page page, String jsCondition) {
        log.debug("Waiting for JS condition: {}", jsCondition);
        page.waitForFunction(jsCondition);
    }
}
