package com.automation.utils;

import com.automation.config.ConfigManager;
import com.microsoft.playwright.Page;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Captures Playwright screenshots with timestamped, filesystem-safe filenames.
 */
public final class ScreenshotUtils {

    private static final Logger log = LogManager.getLogger(ScreenshotUtils.class);
    private static final DateTimeFormatter TIMESTAMP_FMT =
            DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");

    private ScreenshotUtils() {}

    /**
     * Captures a full-page screenshot and saves it to the configured screenshot directory.
     *
     * @param page the Playwright page
     * @param name a descriptive name for the screenshot (will be sanitized)
     * @return absolute path to the saved screenshot, or {@code null} if capture failed
     */
    public static String capture(Page page, String name) {
        try {
            String dir = ConfigManager.getInstance().getScreenshotDir();
            new File(dir).mkdirs();

            String safeName = sanitize(name);
            String timestamp = LocalDateTime.now().format(TIMESTAMP_FMT);
            String filename = safeName + "_" + timestamp + ".png";
            Path path = Paths.get(dir, filename);

            page.screenshot(new Page.ScreenshotOptions()
                    .setPath(path)
                    .setFullPage(true));

            log.info("Screenshot saved: {}", path.toAbsolutePath());
            return path.toAbsolutePath().toString();
        } catch (Exception e) {
            log.warn("Failed to capture screenshot '{}': {}", name, e.getMessage());
            return null;
        }
    }

    private static String sanitize(String name) {
        if (name == null || name.isBlank()) return "screenshot";
        return name.replaceAll("[^a-zA-Z0-9_\\-]", "_").replaceAll("_+", "_");
    }
}
