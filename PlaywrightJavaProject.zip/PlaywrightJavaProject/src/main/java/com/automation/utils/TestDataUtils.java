package com.automation.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.Map;

/**
 * Loads test data from classpath resources for use in test fixtures.
 */
public final class TestDataUtils {

    private static final Logger log = LogManager.getLogger(TestDataUtils.class);

    private TestDataUtils() {}

    /**
     * Loads a JSON file as a list of row maps (the standard dataset format).
     *
     * @param resourcePath classpath-relative path, e.g. {@code "testdata/comparison-test-data.json"}
     * @return list of row maps
     * @throws RuntimeException if the resource is missing or malformed
     */
    public static List<Map<String, Object>> loadDataset(String resourcePath) {
        log.debug("Loading dataset from: {}", resourcePath);
        return JsonUtils.loadResource(resourcePath, new TypeReference<>() {});
    }

    /**
     * Loads a JSON file as a typed object.
     *
     * @param resourcePath classpath-relative path
     * @param typeRef      Jackson type reference
     * @return deserialized object
     */
    public static <T> T loadAs(String resourcePath, TypeReference<T> typeRef) {
        log.debug("Loading test data from: {}", resourcePath);
        return JsonUtils.loadResource(resourcePath, typeRef);
    }
}
