package com.automation.database;

import com.automation.exceptions.DatabaseException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * Convenience facade over {@link SqlQueryExecutor} for loading SQL from
 * classpath resources and executing parameterized queries.
 */
public class DatabaseUtils {

    private static final Logger log = LogManager.getLogger(DatabaseUtils.class);

    private final SqlQueryExecutor executor;

    public DatabaseUtils(SqlQueryExecutor executor) {
        this.executor = executor;
    }

    /**
     * Loads a SQL file from the classpath and executes it with the given parameters.
     *
     * @param resourcePath classpath-relative path, e.g. {@code "sql/powerbi_validation.sql"}
     * @param parameters   positional parameter values
     * @return query results as a list of row maps
     */
    public List<Map<String, Object>> executeQuery(String resourcePath, Object... parameters) {
        String sql = loadSqlResource(resourcePath);
        log.info("Executing SQL resource: {}", resourcePath);
        return executor.executeQuery(sql, parameters);
    }

    /**
     * Executes an inline SQL string with the given parameters.
     *
     * @param sql        the SELECT statement
     * @param parameters positional parameter values
     * @return query results
     */
    public List<Map<String, Object>> executeInlineQuery(String sql, Object... parameters) {
        return executor.executeQuery(sql, parameters);
    }

    /**
     * Loads a SQL file from the classpath and returns its content as a string.
     *
     * @param resourcePath classpath-relative path
     * @return SQL string
     * @throws DatabaseException if the resource cannot be found or read
     */
    public String loadSqlResource(String resourcePath) {
        try (InputStream is = getClass().getClassLoader().getResourceAsStream(resourcePath)) {
            if (is == null) {
                throw new DatabaseException(
                        "SQL resource not found on classpath: '" + resourcePath + "'. " +
                        "Ensure the file exists under src/main/resources/.");
            }
            String sql = new String(is.readAllBytes(), StandardCharsets.UTF_8).strip();
            log.debug("Loaded SQL from '{}' ({} chars).", resourcePath, sql.length());
            return sql;
        } catch (IOException e) {
            throw new DatabaseException("Failed to read SQL resource: " + resourcePath, e);
        }
    }
}
