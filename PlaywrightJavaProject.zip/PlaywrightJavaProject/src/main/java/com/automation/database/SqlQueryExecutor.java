package com.automation.database;

import com.automation.config.ConfigManager;
import com.automation.exceptions.DatabaseException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.*;

/**
 * Executes parameterized SQL SELECT queries and converts results to
 * {@code List<Map<String, Object>>}.
 *
 * <p>Only SELECT statements are permitted. INSERT, UPDATE, DELETE, and DDL
 * operations must never be executed through this class.
 *
 * <p>All JDBC resources are closed via try-with-resources.
 */
public class SqlQueryExecutor {

    private static final Logger log = LogManager.getLogger(SqlQueryExecutor.class);

    private final DatabaseManager databaseManager;
    private final int queryTimeoutSeconds;

    public SqlQueryExecutor(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
        this.queryTimeoutSeconds = ConfigManager.getInstance().getDbQueryTimeoutSeconds();
    }

    /**
     * Executes a parameterized SELECT query and returns all rows.
     *
     * @param sql        the SQL SELECT statement (use {@code ?} for parameters)
     * @param parameters positional parameter values (may be empty)
     * @return list of rows, each row as a column-name-to-value map
     * @throws DatabaseException    if execution fails
     * @throws IllegalArgumentException if the SQL is not a SELECT statement
     */
    public List<Map<String, Object>> executeQuery(String sql, Object... parameters) {
        validateSelectOnly(sql);
        log.debug("Executing query: {}", sql);
        long start = System.currentTimeMillis();

        try (Connection conn = databaseManager.getConnection();
             PreparedStatement stmt = prepareStatement(conn, sql, parameters);
             ResultSet rs = stmt.executeQuery()) {

            List<Map<String, Object>> results = mapResultSet(rs);
            long elapsed = System.currentTimeMillis() - start;
            log.info("Query returned {} rows in {}ms.", results.size(), elapsed);
            return results;

        } catch (SQLException e) {
            throw new DatabaseException("Query execution failed. SQL State: " + e.getSQLState() +
                    ", Error Code: " + e.getErrorCode() + ", Message: " + e.getMessage(), e);
        }
    }

    private PreparedStatement prepareStatement(Connection conn, String sql, Object[] parameters)
            throws SQLException {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setQueryTimeout(queryTimeoutSeconds);
        for (int i = 0; i < parameters.length; i++) {
            stmt.setObject(i + 1, parameters[i]);
        }
        return stmt;
    }

    private List<Map<String, Object>> mapResultSet(ResultSet rs) throws SQLException {
        ResultSetMetaData meta = rs.getMetaData();
        int columnCount = meta.getColumnCount();

        List<String> columnNames = new ArrayList<>(columnCount);
        for (int i = 1; i <= columnCount; i++) {
            columnNames.add(meta.getColumnLabel(i));
        }

        List<Map<String, Object>> rows = new ArrayList<>();
        while (rs.next()) {
            Map<String, Object> row = new LinkedHashMap<>(columnCount);
            for (int i = 1; i <= columnCount; i++) {
                Object value = rs.getObject(i);
                row.put(columnNames.get(i - 1), value);
            }
            rows.add(row);
        }
        return rows;
    }

    private void validateSelectOnly(String sql) {
        String trimmed = sql.strip().toUpperCase();
        if (!trimmed.startsWith("SELECT") && !trimmed.startsWith("WITH")) {
            throw new IllegalArgumentException(
                    "Only SELECT statements are permitted in validation tests. " +
                    "Received: " + sql.substring(0, Math.min(sql.length(), 50)));
        }
    }
}
