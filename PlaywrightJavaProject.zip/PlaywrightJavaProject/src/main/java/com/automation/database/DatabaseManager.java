package com.automation.database;

import com.automation.config.ConfigManager;
import com.automation.exceptions.DatabaseException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Manages JDBC connections to Microsoft SQL Server.
 *
 * <p>Creates a new connection per call. Connection pooling can be added here
 * if throughput requirements justify it.
 *
 * <p>Credentials are read from {@link ConfigManager} and are never logged.
 */
public class DatabaseManager {

    private static final Logger log = LogManager.getLogger(DatabaseManager.class);

    private final ConfigManager config;

    public DatabaseManager() {
        this.config = ConfigManager.getInstance();
    }

    /**
     * Opens and returns a new JDBC connection to the configured SQL Server instance.
     *
     * @return an open {@link Connection}
     * @throws DatabaseException if the connection cannot be established
     */
    public Connection getConnection() {
        String url = buildJdbcUrl();
        log.info("Connecting to SQL Server: {}:{}/{}", config.getDbHost(), config.getDbPort(), config.getDbName());

        try {
            Connection connection = DriverManager.getConnection(url, config.getDbUsername(), config.getDbPassword());
            connection.setReadOnly(true);
            log.info("Database connection established successfully.");
            return connection;
        } catch (SQLException e) {
            throw new DatabaseException(
                    "Failed to connect to SQL Server at " + config.getDbHost() + ":" + config.getDbPort() +
                    " / database '" + config.getDbName() + "'. " +
                    "Verify host, port, database name, credentials, and network access. " +
                    "SQL State: " + e.getSQLState() + ", Error Code: " + e.getErrorCode(), e);
        }
    }

    /**
     * Builds the JDBC URL from configuration.
     * Credentials are passed separately to {@link DriverManager#getConnection}.
     */
    private String buildJdbcUrl() {
        return String.format(
                "jdbc:sqlserver://%s:%d;databaseName=%s;encrypt=%b;trustServerCertificate=%b;loginTimeout=%d",
                config.getDbHost(),
                config.getDbPort(),
                config.getDbName(),
                config.isDbEncrypt(),
                config.isTrustServerCertificate(),
                config.getDbConnectionTimeoutSeconds());
    }
}
