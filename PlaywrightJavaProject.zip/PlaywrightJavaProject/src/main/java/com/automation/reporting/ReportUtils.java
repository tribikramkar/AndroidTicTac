package com.automation.reporting;

import com.automation.models.FieldMismatch;
import com.automation.models.ValidationResult;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.util.List;

/**
 * Reusable helpers for logging test steps, validation results, and artifacts
 * to both ExtentReports and Log4j2.
 */
public final class ReportUtils {

    private static final Logger log = LogManager.getLogger(ReportUtils.class);

    private ReportUtils() {}

    // -------------------------------------------------------------------------
    // Step logging
    // -------------------------------------------------------------------------

    public static void logStep(String message) {
        log.info(message);
        safeLog(test -> test.log(Status.INFO, message));
    }

    public static void logInfo(String message) {
        log.info(message);
        safeLog(test -> test.info(message));
    }

    public static void logWarning(String message) {
        log.warn(message);
        safeLog(test -> test.warning(message));
    }

    public static void logPass(String message) {
        log.info("[PASS] {}", message);
        safeLog(test -> test.pass(message));
    }

    public static void logFail(String message) {
        log.error("[FAIL] {}", message);
        safeLog(test -> test.fail(message));
    }

    public static void logFail(String message, Throwable throwable) {
        log.error("[FAIL] {}", message, throwable);
        safeLog(test -> test.fail(message + "<br>" + throwable.getMessage()));
    }

    public static void logSkip(String message) {
        log.warn("[SKIP] {}", message);
        safeLog(test -> test.skip(message));
    }

    // -------------------------------------------------------------------------
    // Validation result logging
    // -------------------------------------------------------------------------

    /**
     * Logs a full {@link ValidationResult} summary to both ExtentReports and Log4j2.
     */
    public static void logValidationResult(ValidationResult result) {
        String summary = buildSummary(result);
        log.info(summary);

        if (result.isPassed()) {
            safeLog(test -> {
                test.pass("<b>Validation PASSED</b>");
                test.info(summary.replace("\n", "<br>"));
            });
        } else {
            safeLog(test -> {
                test.fail("<b>Validation FAILED</b>");
                test.info(summary.replace("\n", "<br>"));
            });
            logMismatches(result.getMismatches());
        }
    }

    /**
     * Logs row-level and field-level mismatch details.
     */
    public static void logMismatches(List<FieldMismatch> mismatches) {
        if (mismatches == null || mismatches.isEmpty()) return;

        log.warn("Field-level mismatches ({}):", mismatches.size());
        StringBuilder table = new StringBuilder(
                "<table border='1' cellpadding='4'>" +
                "<tr><th>Row Key</th><th>Column</th><th>Expected (DB)</th>" +
                "<th>Actual (UI)</th><th>Type</th><th>Message</th></tr>");

        for (FieldMismatch m : mismatches) {
            log.warn("  Row={} | Col={} | Expected='{}' | Actual='{}' | Type={}",
                    m.getRowKey(), m.getColumnName(), m.getExpectedValue(),
                    m.getActualValue(), m.getMismatchType());
            table.append("<tr>")
                 .append("<td>").append(escape(m.getRowKey())).append("</td>")
                 .append("<td>").append(escape(m.getColumnName())).append("</td>")
                 .append("<td>").append(escape(m.getExpectedValue())).append("</td>")
                 .append("<td>").append(escape(m.getActualValue())).append("</td>")
                 .append("<td>").append(escape(m.getMismatchType())).append("</td>")
                 .append("<td>").append(escape(m.getMessage())).append("</td>")
                 .append("</tr>");
        }
        table.append("</table>");
        safeLog(test -> test.fail(table.toString()));
    }

    /**
     * Attaches a screenshot to the current test report node.
     *
     * @param screenshotPath absolute or relative path to the screenshot file
     */
    public static void attachScreenshot(String screenshotPath) {
        if (screenshotPath == null || !new File(screenshotPath).exists()) {
            log.warn("Screenshot not found at: {}", screenshotPath);
            return;
        }
        log.info("Screenshot captured: {}", screenshotPath);
        safeLog(test -> test.addScreenCaptureFromPath(screenshotPath, "Failure Screenshot"));
    }

    /**
     * Logs a plain artifact path (trace, log file, etc.) as an info entry.
     */
    public static void attachArtifact(String label, String path) {
        log.info("{}: {}", label, path);
        safeLog(test -> test.info(label + ": <code>" + path + "</code>"));
    }

    // -------------------------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------------------------

    private static String buildSummary(ValidationResult result) {
        return String.format(
                "Validation Summary:%n" +
                "  Status          : %s%n" +
                "  DB rows         : %d%n" +
                "  UI rows         : %d%n" +
                "  Matched rows    : %d%n" +
                "  Mismatched rows : %d%n" +
                "  Missing in UI   : %d%n" +
                "  Missing in DB   : %d%n" +
                "  Field mismatches: %d%n" +
                "  Message         : %s",
                result.isPassed() ? "PASSED" : "FAILED",
                result.getDbRowCount(),
                result.getUiRowCount(),
                result.getMatchedRowCount(),
                result.getMismatchedRowCount(),
                result.getMissingInUiCount(),
                result.getMissingInDbCount(),
                result.getFieldMismatchCount(),
                result.getSummary());
    }

    @FunctionalInterface
    private interface TestAction {
        void execute(ExtentTest test) throws Exception;
    }

    private static void safeLog(TestAction action) {
        try {
            action.execute(ExtentReportManager.getTest());
        } catch (IllegalStateException e) {
            // No ExtentTest initialized for this thread — log only to file
            log.debug("ExtentTest not available; skipping report logging.");
        } catch (Exception e) {
            log.warn("Failed to log to ExtentReports: {}", e.getMessage());
        }
    }

    private static String escape(String value) {
        if (value == null) return "<i>null</i>";
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
