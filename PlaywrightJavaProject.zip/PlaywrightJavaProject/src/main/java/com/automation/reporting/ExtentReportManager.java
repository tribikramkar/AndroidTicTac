package com.automation.reporting;

import com.automation.config.ConfigManager;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Manages the ExtentReports lifecycle.
 *
 * <p>One {@link ExtentReports} instance is shared per suite run.
 * Each test thread holds its own {@link ExtentTest} via a {@link ThreadLocal}.
 * Call {@link #flush()} once at suite completion.
 */
public final class ExtentReportManager {

    private static final Logger log = LogManager.getLogger(ExtentReportManager.class);
    private static final DateTimeFormatter TIMESTAMP_FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");

    private static volatile ExtentReports extentReports;
    private static final ThreadLocal<ExtentTest> testHolder = new ThreadLocal<>();

    private ExtentReportManager() {}

    /**
     * Initializes the ExtentReports instance. Safe to call multiple times;
     * subsequent calls are no-ops.
     */
    public static synchronized void initReports() {
        if (extentReports != null) return;

        ConfigManager cfg = ConfigManager.getInstance();
        String reportDir = cfg.getReportDir();
        new File(reportDir).mkdirs();

        String timestamp = LocalDateTime.now().format(TIMESTAMP_FMT);
        String reportPath = reportDir + File.separator + "AutomationReport_" + timestamp + ".html";

        ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);
        sparkReporter.config().setTheme(Theme.DARK);
        sparkReporter.config().setDocumentTitle(cfg.getAppName() + " - Test Report");
        sparkReporter.config().setReportName(cfg.getAppName());
        sparkReporter.config().setEncoding("UTF-8");

        extentReports = new ExtentReports();
        extentReports.attachReporter(sparkReporter);
        extentReports.setSystemInfo("Environment", cfg.getEnvironment());
        extentReports.setSystemInfo("Browser",     cfg.getBrowserType());
        extentReports.setSystemInfo("OS",          System.getProperty("os.name"));
        extentReports.setSystemInfo("Java",        System.getProperty("java.version"));

        log.info("ExtentReports initialized. Report path: {}", reportPath);
    }

    /**
     * Creates a new test node in the report for the current thread.
     *
     * @param testName        display name of the test
     * @param testDescription optional description
     */
    public static void createTest(String testName, String testDescription) {
        if (extentReports == null) {
            initReports();
        }
        ExtentTest test = extentReports.createTest(testName, testDescription);
        testHolder.set(test);
    }

    /**
     * Returns the {@link ExtentTest} for the current thread.
     *
     * @throws IllegalStateException if {@link #createTest} has not been called
     */
    public static ExtentTest getTest() {
        ExtentTest test = testHolder.get();
        if (test == null) {
            throw new IllegalStateException(
                    "ExtentTest not initialized for this thread. Call createTest() first.");
        }
        return test;
    }

    /**
     * Removes the current thread's test reference. Call in test teardown.
     */
    public static void removeTest() {
        testHolder.remove();
    }

    /**
     * Flushes all test results to the HTML report file.
     * Must be called once at suite completion (e.g., in a TestNG suite listener).
     */
    public static synchronized void flush() {
        if (extentReports != null) {
            extentReports.flush();
            log.info("ExtentReports flushed.");
        }
    }
}
