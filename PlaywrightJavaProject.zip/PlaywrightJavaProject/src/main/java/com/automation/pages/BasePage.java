package com.automation.pages;

import com.automation.components.PageElement;
import com.automation.exceptions.PageException;
import com.automation.utils.ScreenshotUtils;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.options.LoadState;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Base page object.
 *
 * <p>Every page object must extend this class and call
 * {@code ElementFactory.initElements(page, this)} in its constructor to inject
 * all {@code @FindBy}-annotated {@link PageElement} fields.
 *
 * <pre>{@code
 * public class MyPage extends BasePage {
 *
 *     @FindBy(css = "#username")
 *     private PageElement usernameField;
 *
 *     @FindBy(role = "BUTTON", name = "Sign In")
 *     private PageElement signInButton;
 *
 *     public MyPage(Page page) {
 *         super(page);
 *         ElementFactory.initElements(page, this);
 *     }
 * }
 * }</pre>
 */
public abstract class BasePage {

    protected final Logger log = LogManager.getLogger(getClass());
    protected final Page page;

    protected BasePage(Page page) {
        this.page = page;
    }

    // -------------------------------------------------------------------------
    // Navigation
    // -------------------------------------------------------------------------

    protected void navigate(String url) {
        log.info("Navigating to: {}", url);
        try {
            page.navigate(url);
        } catch (PlaywrightException e) {
            throw new PageException("Navigation failed for URL: " + url, e);
        }
    }

    protected void waitForPageLoad() {
        try {
            page.waitForLoadState(LoadState.LOAD);
        } catch (PlaywrightException e) {
            throw new PageException("Timed out waiting for page load.", e);
        }
    }

    protected void waitForNetworkIdle() {
        try {
            page.waitForLoadState(LoadState.NETWORKIDLE);
        } catch (PlaywrightException e) {
            throw new PageException("Timed out waiting for network idle.", e);
        }
    }

    // -------------------------------------------------------------------------
    // PageElement factory — create elements on the fly when @FindBy is not used
    // -------------------------------------------------------------------------

    /**
     * Creates a {@link PageElement} from a CSS selector at runtime.
     * Use this for dynamic selectors that cannot be declared as {@code @FindBy} fields.
     */
    protected PageElement $(String cssSelector) {
        return new PageElement(page.locator(cssSelector), cssSelector);
    }

    /**
     * Creates a {@link PageElement} from an XPath expression at runtime.
     */
    protected PageElement $x(String xpath) {
        return new PageElement(page.locator("xpath=" + xpath), "xpath=" + xpath);
    }

    // -------------------------------------------------------------------------
    // Interactions via PageElement
    // -------------------------------------------------------------------------

    protected void click(PageElement element) {
        log.debug("Clicking: {}", element.getDescription());
        element.click();
    }

    protected void fill(PageElement element, String value) {
        log.debug("Filling '{}' into: {}", value, element.getDescription());
        element.fill(value);
    }

    protected void selectOption(PageElement element, String value) {
        log.debug("Selecting '{}' in: {}", value, element.getDescription());
        element.selectOption(value);
    }

    protected String getText(PageElement element) {
        return element.getText();
    }

    protected String getAttribute(PageElement element, String attribute) {
        return element.getAttribute(attribute);
    }

    protected boolean isVisible(PageElement element) {
        return element.isVisible();
    }

    protected void waitForVisible(PageElement element) {
        log.debug("Waiting for visible: {}", element.getDescription());
        element.waitForVisible();
    }

    protected void waitForHidden(PageElement element) {
        log.debug("Waiting for hidden: {}", element.getDescription());
        element.waitForHidden();
    }

    // -------------------------------------------------------------------------
    // Table extraction via PageElement
    // -------------------------------------------------------------------------

    /**
     * Reads all header text values from a {@link PageElement} pointing to a {@code <table>}.
     */
    protected List<String> readTableHeaders(PageElement tableElement) {
        List<String> headers = new ArrayList<>();
        PageElement headerCells = tableElement.find("thead th");
        int count = headerCells.count();
        for (int i = 0; i < count; i++) {
            headers.add(headerCells.nth(i).getText());
        }
        return headers;
    }

    /**
     * Reads all data rows from a {@link PageElement} pointing to a {@code <table>}.
     */
    protected List<List<String>> readTableRows(PageElement tableElement) {
        List<List<String>> rows = new ArrayList<>();
        PageElement dataRows = tableElement.find("tbody tr");
        int rowCount = dataRows.count();
        for (int r = 0; r < rowCount; r++) {
            PageElement cells = dataRows.nth(r).find("td");
            int cellCount = cells.count();
            List<String> row = new ArrayList<>(cellCount);
            for (int c = 0; c < cellCount; c++) {
                row.add(cells.nth(c).getText());
            }
            rows.add(row);
        }
        return rows;
    }

    /**
     * Extracts a full HTML table into a list of column-name-to-value maps.
     */
    protected List<Map<String, Object>> extractTableData(PageElement tableElement) {
        List<String> headers = readTableHeaders(tableElement);
        List<List<String>> rows = readTableRows(tableElement);

        List<Map<String, Object>> result = new ArrayList<>(rows.size());
        for (List<String> row : rows) {
            Map<String, Object> rowMap = new LinkedHashMap<>();
            for (int i = 0; i < headers.size(); i++) {
                rowMap.put(headers.get(i), i < row.size() ? row.get(i) : null);
            }
            result.add(rowMap);
        }
        return result;
    }

    // -------------------------------------------------------------------------
    // Screenshots
    // -------------------------------------------------------------------------

    protected String takeScreenshot(String name) {
        return ScreenshotUtils.capture(page, name);
    }
}
