package com.automation.config;

import com.automation.exceptions.ConfigurationException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * Validates that all required configuration properties are present before
 * integration tests start. Provides actionable error messages for missing values.
 */
public final class ConfigurationValidator {

    private static final Logger log = LogManager.getLogger(ConfigurationValidator.class);

    private ConfigurationValidator() {}

    /**
     * Validates properties required for full UI + database integration tests.
     *
     * @throws ConfigurationException if any required property is missing
     */
    public static void validateIntegrationConfig() {
        ConfigManager cfg = ConfigManager.getInstance();
        List<String> missing = new ArrayList<>();

        requireNonBlank(cfg.getDashboardUrl(),  "dashboard.url",  missing);
        requireNonBlank(cfg.getReportName(),    "dashboard.report.name", missing);
        requireNonBlank(cfg.getPageName(),      "dashboard.page.name",   missing);
        requireNonBlank(cfg.getVisualId(),      "dashboard.visual.id",   missing);
        requireNonBlank(cfg.getDbHost(),        "db.host",        missing);
        requireNonBlank(cfg.getDbName(),        "db.name",        missing);
        requireNonBlank(cfg.getDbUsername(),    "db.username",    missing);
        requireNonBlank(cfg.getDbPassword(),    "db.password",    missing);

        if (!missing.isEmpty()) {
            String message = buildErrorMessage(missing);
            log.error(message);
            throw new ConfigurationException(message);
        }

        log.info("Integration configuration validated successfully.");
    }

    /**
     * Validates only the database-related properties.
     *
     * @throws ConfigurationException if any required DB property is missing
     */
    public static void validateDatabaseConfig() {
        ConfigManager cfg = ConfigManager.getInstance();
        List<String> missing = new ArrayList<>();

        requireNonBlank(cfg.getDbHost(),     "db.host",     missing);
        requireNonBlank(cfg.getDbName(),     "db.name",     missing);
        requireNonBlank(cfg.getDbUsername(), "db.username", missing);
        requireNonBlank(cfg.getDbPassword(), "db.password", missing);

        if (!missing.isEmpty()) {
            String message = buildErrorMessage(missing);
            log.error(message);
            throw new ConfigurationException(message);
        }

        log.info("Database configuration validated successfully.");
    }

    /**
     * Validates only the browser/UI-related properties.
     *
     * @throws ConfigurationException if any required UI property is missing
     */
    public static void validateUiConfig() {
        ConfigManager cfg = ConfigManager.getInstance();
        List<String> missing = new ArrayList<>();

        requireNonBlank(cfg.getDashboardUrl(), "dashboard.url", missing);

        if (!missing.isEmpty()) {
            String message = buildErrorMessage(missing);
            log.error(message);
            throw new ConfigurationException(message);
        }

        log.info("UI configuration validated successfully.");
    }

    private static void requireNonBlank(String value, String key, List<String> missing) {
        if (value == null || value.isBlank()) {
            missing.add(key);
        }
    }

    private static String buildErrorMessage(List<String> missingKeys) {
        StringBuilder sb = new StringBuilder();
        sb.append("Configuration validation failed. The following required properties are missing or blank:\n");
        for (String key : missingKeys) {
            sb.append("  - ").append(key).append("\n");
        }
        sb.append("\nSet them via:\n");
        sb.append("  1. JVM system property:  -D").append(missingKeys.get(0)).append("=<value>\n");
        sb.append("  2. Environment variable: ")
          .append(missingKeys.get(0).replace('.', '_').replace('-', '_').toUpperCase())
          .append("=<value>\n");
        sb.append("  3. src/main/resources/config.properties\n");
        sb.append("\nSee .env.example for a full list of required variables.");
        return sb.toString();
    }
}
