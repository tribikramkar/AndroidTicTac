package com.automation.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Centralized configuration manager.
 *
 * <p>Resolution order (highest to lowest priority):
 * <ol>
 *   <li>JVM system property  (-Dproperty.name=value)</li>
 *   <li>Environment variable (PROPERTY_NAME in UPPER_SNAKE_CASE)</li>
 *   <li>config.properties defaults</li>
 * </ol>
 */
public final class ConfigManager {

    private static final Logger log = LogManager.getLogger(ConfigManager.class);
    private static final String CONFIG_FILE = "config.properties";

    private static volatile ConfigManager instance;
    private final Properties properties;

    private ConfigManager() {
        properties = new Properties();
        loadPropertiesFile();
    }

    public static ConfigManager getInstance() {
        if (instance == null) {
            synchronized (ConfigManager.class) {
                if (instance == null) {
                    instance = new ConfigManager();
                }
            }
        }
        return instance;
    }

    private void loadPropertiesFile() {
        try (InputStream is = getClass().getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (is == null) {
                log.warn("'{}' not found on classpath; relying on system properties and environment variables.", CONFIG_FILE);
                return;
            }
            properties.load(is);
            log.debug("Loaded configuration from '{}'.", CONFIG_FILE);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load " + CONFIG_FILE, e);
        }
    }

    /**
     * Resolves a property value using the three-tier precedence.
     *
     * @param key property key as defined in config.properties
     * @return resolved value, or {@code null} if not found
     */
    public String get(String key) {
        // 1. JVM system property
        String value = System.getProperty(key);
        if (value != null && !value.isBlank()) {
            return value.trim();
        }
        // 2. Environment variable (dots and hyphens → underscores, uppercase)
        String envKey = key.replace('.', '_').replace('-', '_').toUpperCase();
        value = System.getenv(envKey);
        if (value != null && !value.isBlank()) {
            return value.trim();
        }
        // 3. config.properties
        value = properties.getProperty(key);
        return (value != null) ? value.trim() : null;
    }

    /**
     * Returns the resolved value, or {@code defaultValue} when not found.
     */
    public String get(String key, String defaultValue) {
        String value = get(key);
        return (value != null) ? value : defaultValue;
    }

    /**
     * Returns the resolved value as a boolean.
     */
    public boolean getBoolean(String key, boolean defaultValue) {
        String value = get(key);
        return (value != null) ? Boolean.parseBoolean(value) : defaultValue;
    }

    /**
     * Returns the resolved value as an int.
     */
    public int getInt(String key, int defaultValue) {
        String value = get(key);
        if (value == null) return defaultValue;
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            log.warn("Invalid integer for key '{}': '{}'. Using default {}.", key, value, defaultValue);
            return defaultValue;
        }
    }

    // -------------------------------------------------------------------------
    // Typed accessors
    // -------------------------------------------------------------------------

    public String getAppName()               { return get("app.name", "Automation Framework"); }
    public String getEnvironment()           { return get("app.environment", "dev"); }

    public String getDashboardUrl()          { return get("dashboard.url"); }
    public String getReportName()            { return get("dashboard.report.name"); }
    public String getPageName()              { return get("dashboard.page.name"); }
    public String getVisualId()              { return get("dashboard.visual.id"); }

    public String getBrowserType()           { return get("browser.type", "chromium"); }
    public boolean isHeadless()              { return getBoolean("browser.headless", false); }
    public int getBrowserTimeoutMs()         { return getInt("browser.timeout.ms", 30000); }
    public int getNavigationTimeoutMs()      { return getInt("browser.navigation.timeout.ms", 60000); }
    public int getViewportWidth()            { return getInt("browser.viewport.width", 1920); }
    public int getViewportHeight()           { return getInt("browser.viewport.height", 1080); }
    public boolean isScreenshotOnFailure()   { return getBoolean("browser.screenshot.on.failure", true); }
    public boolean isTracingEnabled()        { return getBoolean("browser.tracing.enabled", false); }

    public String getDbHost()               { return get("db.host"); }
    public int getDbPort()                  { return getInt("db.port", 1433); }
    public String getDbName()               { return get("db.name"); }
    public String getDbUsername()           { return get("db.username"); }
    public String getDbPassword()           { return get("db.password"); }
    public boolean isDbEncrypt()            { return getBoolean("db.encrypt", true); }
    public boolean isTrustServerCertificate() { return getBoolean("db.trust.server.certificate", false); }
    public int getDbConnectionTimeoutSeconds() { return getInt("db.connection.timeout.seconds", 30); }
    public int getDbQueryTimeoutSeconds()   { return getInt("db.query.timeout.seconds", 120); }

    public String getReportDir()            { return get("report.dir", "reports"); }
    public String getLogDir()               { return get("log.dir", "logs"); }
    public String getScreenshotDir()        { return get("screenshot.dir", "screenshots"); }
    public String getTraceDir()             { return get("trace.dir", "traces"); }
}
