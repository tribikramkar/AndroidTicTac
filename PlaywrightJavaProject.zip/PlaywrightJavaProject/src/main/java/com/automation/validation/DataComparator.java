package com.automation.validation;

import com.automation.models.ComparisonConfig;
import com.automation.models.FieldMismatch;
import com.automation.models.ValidationResult;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;

/**
 * Core dataset comparison engine.
 *
 * <p>Compares an expected database dataset against an actual UI dataset using
 * the rules defined in {@link ComparisonConfig}. Returns a deterministic
 * {@link ValidationResult} with full mismatch details.
 *
 * <p>This class has no dependency on Playwright, JDBC, TestNG, or ExtentReports
 * and can be unit-tested without any external infrastructure.
 */
public class DataComparator {

    private static final Logger log = LogManager.getLogger(DataComparator.class);

    /**
     * Compares the expected DB dataset against the actual UI dataset.
     *
     * @param dbData   expected dataset from the database (source of truth)
     * @param uiData   actual dataset extracted from the UI
     * @param config   comparison configuration
     * @return a fully populated {@link ValidationResult}
     */
    public ValidationResult compare(List<Map<String, Object>> dbData,
                                    List<Map<String, Object>> uiData,
                                    ComparisonConfig config) {
        log.info("Starting comparison. DB rows: {}, UI rows: {}", dbData.size(), uiData.size());

        ValidationResult result = new ValidationResult()
                .dbRowCount(dbData.size())
                .uiRowCount(uiData.size());

        // --- Empty dataset checks ---
        if (dbData.isEmpty() && uiData.isEmpty()) {
            return result.passed(true)
                         .summary("Both datasets are empty. Comparison passed.")
                         .matchedRowCount(0);
        }
        if (dbData.isEmpty()) {
            return result.passed(false)
                         .summary("DB dataset is empty but UI dataset has " + uiData.size() + " rows.")
                         .missingInDbCount(uiData.size());
        }
        if (uiData.isEmpty()) {
            return result.passed(false)
                         .summary("UI dataset is empty but DB dataset has " + dbData.size() + " rows.")
                         .missingInUiCount(dbData.size());
        }

        // --- Column validation ---
        if (config.isValidateColumns()) {
            List<String> columnErrors = validateColumns(dbData.get(0), uiData.get(0), config);
            if (!columnErrors.isEmpty()) {
                return result.passed(false)
                             .summary("Column validation failed: " + String.join("; ", columnErrors));
            }
        }

        // --- Build UI lookup map keyed by business key ---
        Map<String, List<Map<String, Object>>> uiIndex = buildIndex(uiData, config, "UI");
        Map<String, List<Map<String, Object>>> dbIndex = buildIndex(dbData, config, "DB");

        // Detect duplicate keys
        List<String> duplicateErrors = detectDuplicates(uiIndex, "UI");
        duplicateErrors.addAll(detectDuplicates(dbIndex, "DB"));
        if (!duplicateErrors.isEmpty()) {
            return result.passed(false)
                         .summary("Duplicate business keys detected: " + String.join("; ", duplicateErrors));
        }

        int matched = 0;
        int mismatched = 0;
        int missingInUi = 0;
        int missingInDb = 0;
        boolean allPassed = true;

        // --- Match DB rows against UI rows ---
        for (Map.Entry<String, List<Map<String, Object>>> entry : dbIndex.entrySet()) {
            String key = entry.getKey();
            Map<String, Object> dbRow = entry.getValue().get(0);

            if (!uiIndex.containsKey(key)) {
                log.warn("DB row with key '{}' not found in UI data.", key);
                result.addMissingInUiKey(key);
                missingInUi++;
                allPassed = false;
                continue;
            }

            Map<String, Object> uiRow = uiIndex.get(key).get(0);
            List<FieldMismatch> rowMismatches = compareRow(key, dbRow, uiRow, config);

            if (rowMismatches.isEmpty()) {
                matched++;
            } else {
                mismatched++;
                allPassed = false;
                rowMismatches.forEach(result::addMismatch);
            }
        }

        // --- Find UI rows with no matching DB row ---
        for (String key : uiIndex.keySet()) {
            if (!dbIndex.containsKey(key)) {
                log.warn("UI row with key '{}' not found in DB data.", key);
                result.addMissingInDbKey(key);
                missingInDb++;
                allPassed = false;
            }
        }

        // --- Row count check ---
        if (config.isValidateRowCount() && dbData.size() != uiData.size()) {
            allPassed = false;
        }

        result.matchedRowCount(matched)
              .mismatchedRowCount(mismatched)
              .missingInUiCount(missingInUi)
              .missingInDbCount(missingInDb)
              .fieldMismatchCount(result.getMismatches().size())
              .passed(allPassed)
              .summary(buildSummary(allPassed, dbData.size(), uiData.size(),
                                    matched, mismatched, missingInUi, missingInDb,
                                    result.getMismatches().size()));

        log.info("Comparison complete. {}", result);
        return result;
    }

    // -------------------------------------------------------------------------
    // Row comparison
    // -------------------------------------------------------------------------

    private List<FieldMismatch> compareRow(String rowKey,
                                           Map<String, Object> dbRow,
                                           Map<String, Object> uiRow,
                                           ComparisonConfig config) {
        List<FieldMismatch> mismatches = new ArrayList<>();

        for (String dbColumn : dbRow.keySet()) {
            if (config.isIgnored(dbColumn)) continue;

            String uiColumn = config.resolveUiColumn(dbColumn);

            if (!uiRow.containsKey(uiColumn)) {
                mismatches.add(new FieldMismatch(rowKey, dbColumn,
                        stringify(dbRow.get(dbColumn)), null,
                        "MISSING_UI_COLUMN",
                        "UI row does not contain column '" + uiColumn + "'"));
                continue;
            }

            String normalizedExpected = ValidationUtils.normalize(dbRow.get(dbColumn), config);
            String normalizedActual   = ValidationUtils.normalize(uiRow.get(uiColumn), config);

            if (!ValidationUtils.valuesEqual(normalizedExpected, normalizedActual, config)) {
                mismatches.add(new FieldMismatch(
                        rowKey, dbColumn,
                        stringify(dbRow.get(dbColumn)),
                        stringify(uiRow.get(uiColumn)),
                        "VALUE_MISMATCH",
                        String.format("Expected '%s' but found '%s' (normalized: '%s' vs '%s')",
                                dbRow.get(dbColumn), uiRow.get(uiColumn),
                                normalizedExpected, normalizedActual)));
            }
        }

        return mismatches;
    }

    // -------------------------------------------------------------------------
    // Index building
    // -------------------------------------------------------------------------

    private Map<String, List<Map<String, Object>>> buildIndex(List<Map<String, Object>> dataset,
                                                               ComparisonConfig config,
                                                               String datasetLabel) {
        Map<String, List<Map<String, Object>>> index = new LinkedHashMap<>();
        List<String> keyColumns = resolveKeyColumns(dataset.get(0), config, datasetLabel);

        for (Map<String, Object> row : dataset) {
            String key = ValidationUtils.buildKey(row, keyColumns, config);
            index.computeIfAbsent(key, k -> new ArrayList<>()).add(row);
        }
        return index;
    }

    private List<String> resolveKeyColumns(Map<String, Object> sampleRow,
                                            ComparisonConfig config,
                                            String datasetLabel) {
        List<String> keys = config.getBusinessKeys();
        for (String key : keys) {
            if (!sampleRow.containsKey(key)) {
                throw new IllegalArgumentException(
                        "Business key column '" + key + "' not found in " + datasetLabel +
                        " dataset. Available columns: " + sampleRow.keySet());
            }
        }
        return keys;
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private List<String> detectDuplicates(Map<String, List<Map<String, Object>>> index,
                                           String label) {
        List<String> errors = new ArrayList<>();
        for (Map.Entry<String, List<Map<String, Object>>> entry : index.entrySet()) {
            if (entry.getValue().size() > 1) {
                errors.add(label + " has " + entry.getValue().size() +
                           " rows with key '" + entry.getKey() + "'");
            }
        }
        return errors;
    }

    private List<String> validateColumns(Map<String, Object> dbSampleRow,
                                          Map<String, Object> uiSampleRow,
                                          ComparisonConfig config) {
        List<String> errors = new ArrayList<>();
        for (String dbCol : dbSampleRow.keySet()) {
            if (config.isIgnored(dbCol)) continue;
            String uiCol = config.resolveUiColumn(dbCol);
            if (!uiSampleRow.containsKey(uiCol)) {
                errors.add("UI dataset missing column '" + uiCol +
                           "' (mapped from DB column '" + dbCol + "')");
            }
        }
        return errors;
    }

    private String stringify(Object value) {
        return value == null ? null : value.toString();
    }

    private String buildSummary(boolean passed, int dbCount, int uiCount,
                                 int matched, int mismatched,
                                 int missingUi, int missingDb, int fieldMismatches) {
        return String.format(
                "%s | DB=%d, UI=%d, Matched=%d, Mismatched=%d, MissingUI=%d, MissingDB=%d, FieldMismatches=%d",
                passed ? "PASSED" : "FAILED",
                dbCount, uiCount, matched, mismatched, missingUi, missingDb, fieldMismatches);
    }
}
