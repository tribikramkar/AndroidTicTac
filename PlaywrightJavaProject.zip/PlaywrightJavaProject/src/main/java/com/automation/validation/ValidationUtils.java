package com.automation.validation;

import com.automation.models.ComparisonConfig;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.math.BigDecimal;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Map;

/**
 * Normalization and assertion helpers used by the comparison engine.
 */
public final class ValidationUtils {

    private static final Logger log = LogManager.getLogger(ValidationUtils.class);

    private ValidationUtils() {}

    /**
     * Converts a raw value from a dataset row to a normalized string for comparison.
     *
     * @param raw    the raw value (may be null, String, Number, Date, etc.)
     * @param config comparison configuration controlling normalization rules
     * @return normalized string representation, or {@code null} if raw is null
     *         and {@code treatNullAsEmpty} is false
     */
    public static String normalize(Object raw, ComparisonConfig config) {
        if (raw == null) {
            return config.isTreatNullAsEmpty() ? "" : null;
        }

        String value;

        if (raw instanceof java.sql.Timestamp ts) {
            value = normalizeTimestamp(ts, config);
        } else if (raw instanceof java.sql.Date sd) {
            value = normalizeDate(sd.toLocalDate(), config);
        } else if (raw instanceof java.util.Date d) {
            value = normalizeDate(d.toInstant().atZone(ZoneId.of(config.getTimezone())).toLocalDate(), config);
        } else if (raw instanceof LocalDate ld) {
            value = normalizeDate(ld, config);
        } else if (raw instanceof LocalDateTime ldt) {
            value = normalizeLocalDateTime(ldt, config);
        } else if (raw instanceof Number n) {
            value = normalizeNumber(n.toString());
        } else {
            // Attempt to normalize string values that look like numbers
            String strVal = raw.toString();
            value = tryNormalizeNumericString(strVal);
        }

        if (config.isNormalizeWhitespace() && value != null) {
            value = value.strip().replaceAll("\\s+", " ");
        }

        if (!config.isCaseSensitive() && value != null) {
            value = value.toLowerCase();
        }

        return value;
    }

    /**
     * Compares two normalized string values, applying decimal tolerance when both
     * values are numeric.
     *
     * @return true if the values are considered equal under the given config
     */
    public static boolean valuesEqual(String normalizedExpected, String normalizedActual,
                                      ComparisonConfig config) {
        if (normalizedExpected == null && normalizedActual == null) return true;
        if (normalizedExpected == null || normalizedActual == null) return false;

        // Attempt numeric comparison with tolerance
        if (config.getDecimalTolerance() > 0) {
            try {
                BigDecimal bdExpected = new BigDecimal(normalizedExpected.trim());
                BigDecimal bdActual   = new BigDecimal(normalizedActual.trim());
                return bdExpected.subtract(bdActual).abs()
                        .compareTo(BigDecimal.valueOf(config.getDecimalTolerance())) <= 0;
            } catch (NumberFormatException ignored) {
                // Not numeric — fall through to string comparison
            }
        }

        return normalizedExpected.equals(normalizedActual);
    }

    /**
     * Builds a composite business key string from a dataset row.
     *
     * @param row        the data row
     * @param keyColumns the column names that form the key
     * @param config     comparison config for normalization
     * @return composite key string, e.g. "value1|value2"
     */
    public static String buildKey(Map<String, Object> row, java.util.List<String> keyColumns,
                                  ComparisonConfig config) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < keyColumns.size(); i++) {
            if (i > 0) sb.append("|");
            Object val = row.get(keyColumns.get(i));
            String normalized = normalize(val, config);
            sb.append(normalized != null ? normalized : "<null>");
        }
        return sb.toString();
    }

    // -------------------------------------------------------------------------
    // Private normalization helpers
    // -------------------------------------------------------------------------

    private static String normalizeNumber(String value) {
        try {
            BigDecimal bd = new BigDecimal(value).stripTrailingZeros();
            return bd.toPlainString();
        } catch (NumberFormatException e) {
            return value;
        }
    }

    /**
     * If the string looks like a number, normalizes it via BigDecimal.
     * Otherwise returns the original string unchanged.
     */
    private static String tryNormalizeNumericString(String value) {
        try {
            BigDecimal bd = new BigDecimal(value.trim()).stripTrailingZeros();
            return bd.toPlainString();
        } catch (NumberFormatException e) {
            return value;
        }
    }

    private static String normalizeDate(LocalDate date, ComparisonConfig config) {
        if (!config.isNormalizeDates()) return date.toString();
        try {
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern(config.getDateFormat());
            return date.format(fmt);
        } catch (Exception e) {
            log.warn("Failed to format date '{}' with pattern '{}': {}",
                    date, config.getDateFormat(), e.getMessage());
            return date.toString();
        }
    }

    private static String normalizeTimestamp(java.sql.Timestamp ts, ComparisonConfig config) {
        if (!config.isNormalizeDates()) return ts.toString();
        try {
            ZoneId zone = ZoneId.of(config.getTimezone());
            LocalDateTime ldt = ts.toLocalDateTime();
            ZonedDateTime zdt = ldt.atZone(ZoneId.systemDefault()).withZoneSameInstant(zone);
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern(config.getDateFormat());
            return zdt.format(fmt);
        } catch (Exception e) {
            log.warn("Failed to normalize timestamp '{}': {}", ts, e.getMessage());
            return ts.toString();
        }
    }

    private static String normalizeLocalDateTime(LocalDateTime ldt, ComparisonConfig config) {
        if (!config.isNormalizeDates()) return ldt.toString();
        try {
            ZoneId zone = ZoneId.of(config.getTimezone());
            ZonedDateTime zdt = ldt.atZone(ZoneId.systemDefault()).withZoneSameInstant(zone);
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern(config.getDateFormat());
            return zdt.format(fmt);
        } catch (Exception e) {
            log.warn("Failed to normalize LocalDateTime '{}': {}", ldt, e.getMessage());
            return ldt.toString();
        }
    }

    /**
     * Attempts to parse a string value as a date using the configured format,
     * then re-formats it for normalized comparison.
     *
     * @return normalized date string, or the original value if parsing fails
     */
    public static String normalizeDateString(String value, ComparisonConfig config) {
        if (value == null || !config.isNormalizeDates()) return value;
        try {
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern(config.getDateFormat());
            LocalDate date = LocalDate.parse(value.trim(), fmt);
            return date.format(fmt);
        } catch (DateTimeParseException e) {
            return value;
        }
    }
}
