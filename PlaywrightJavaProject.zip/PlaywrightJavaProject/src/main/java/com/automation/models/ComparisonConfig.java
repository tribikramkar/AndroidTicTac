package com.automation.models;

import java.util.*;

/**
 * Configuration for a single dataset comparison run.
 *
 * <p>Use the {@link Builder} to construct instances.
 *
 * <pre>{@code
 * ComparisonConfig config = ComparisonConfig.builder()
 *     .businessKeys(List.of("OrderId"))
 *     .columnMapping("order_id", "OrderId")
 *     .ignoreColumn("LastUpdated")
 *     .decimalTolerance(0.01)
 *     .caseSensitive(false)
 *     .normalizeWhitespace(true)
 *     .build();
 * }</pre>
 */
public class ComparisonConfig {

    private final List<String> businessKeys;
    private final Map<String, String> columnMappings;   // dbColumn -> uiColumn
    private final Set<String> ignoredColumns;
    private final boolean caseSensitive;
    private final boolean normalizeWhitespace;
    private final boolean treatNullAsEmpty;
    private final double decimalTolerance;
    private final boolean normalizeDates;
    private final String dateFormat;
    private final String timezone;
    private final boolean validateRowCount;
    private final boolean validateColumns;

    private ComparisonConfig(Builder builder) {
        this.businessKeys       = Collections.unmodifiableList(new ArrayList<>(builder.businessKeys));
        this.columnMappings     = Collections.unmodifiableMap(new LinkedHashMap<>(builder.columnMappings));
        this.ignoredColumns     = Collections.unmodifiableSet(new LinkedHashSet<>(builder.ignoredColumns));
        this.caseSensitive      = builder.caseSensitive;
        this.normalizeWhitespace = builder.normalizeWhitespace;
        this.treatNullAsEmpty   = builder.treatNullAsEmpty;
        this.decimalTolerance   = builder.decimalTolerance;
        this.normalizeDates     = builder.normalizeDates;
        this.dateFormat         = builder.dateFormat;
        this.timezone           = builder.timezone;
        this.validateRowCount   = builder.validateRowCount;
        this.validateColumns    = builder.validateColumns;
    }

    public static Builder builder() { return new Builder(); }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    public List<String> getBusinessKeys()           { return businessKeys; }
    public Map<String, String> getColumnMappings()  { return columnMappings; }
    public Set<String> getIgnoredColumns()          { return ignoredColumns; }
    public boolean isCaseSensitive()                { return caseSensitive; }
    public boolean isNormalizeWhitespace()          { return normalizeWhitespace; }
    public boolean isTreatNullAsEmpty()             { return treatNullAsEmpty; }
    public double getDecimalTolerance()             { return decimalTolerance; }
    public boolean isNormalizeDates()               { return normalizeDates; }
    public String getDateFormat()                   { return dateFormat; }
    public String getTimezone()                     { return timezone; }
    public boolean isValidateRowCount()             { return validateRowCount; }
    public boolean isValidateColumns()              { return validateColumns; }

    /**
     * Returns the UI column name that maps to the given DB column name.
     * If no explicit mapping exists, returns the DB column name unchanged.
     */
    public String resolveUiColumn(String dbColumn) {
        return columnMappings.getOrDefault(dbColumn, dbColumn);
    }

    public boolean isIgnored(String columnName) {
        return ignoredColumns.contains(columnName);
    }

    // -------------------------------------------------------------------------
    // Builder
    // -------------------------------------------------------------------------

    public static class Builder {

        private final List<String> businessKeys   = new ArrayList<>();
        private final Map<String, String> columnMappings = new LinkedHashMap<>();
        private final Set<String> ignoredColumns  = new LinkedHashSet<>();
        private boolean caseSensitive             = false;
        private boolean normalizeWhitespace       = true;
        private boolean treatNullAsEmpty          = false;
        private double decimalTolerance           = 0.0;
        private boolean normalizeDates            = true;
        private String dateFormat                 = "yyyy-MM-dd";
        private String timezone                   = "UTC";
        private boolean validateRowCount          = true;
        private boolean validateColumns           = false;

        public Builder businessKeys(List<String> keys) {
            this.businessKeys.addAll(keys);
            return this;
        }

        public Builder businessKey(String key) {
            this.businessKeys.add(key);
            return this;
        }

        /** Maps a DB column name to its corresponding UI column name. */
        public Builder columnMapping(String dbColumn, String uiColumn) {
            this.columnMappings.put(dbColumn, uiColumn);
            return this;
        }

        public Builder ignoreColumn(String column) {
            this.ignoredColumns.add(column);
            return this;
        }

        public Builder ignoredColumns(List<String> columns) {
            this.ignoredColumns.addAll(columns);
            return this;
        }

        public Builder caseSensitive(boolean caseSensitive) {
            this.caseSensitive = caseSensitive;
            return this;
        }

        public Builder normalizeWhitespace(boolean normalize) {
            this.normalizeWhitespace = normalize;
            return this;
        }

        public Builder treatNullAsEmpty(boolean treatNullAsEmpty) {
            this.treatNullAsEmpty = treatNullAsEmpty;
            return this;
        }

        public Builder decimalTolerance(double tolerance) {
            this.decimalTolerance = tolerance;
            return this;
        }

        public Builder normalizeDates(boolean normalize) {
            this.normalizeDates = normalize;
            return this;
        }

        public Builder dateFormat(String format) {
            this.dateFormat = format;
            return this;
        }

        public Builder timezone(String timezone) {
            this.timezone = timezone;
            return this;
        }

        public Builder validateRowCount(boolean validate) {
            this.validateRowCount = validate;
            return this;
        }

        public Builder validateColumns(boolean validate) {
            this.validateColumns = validate;
            return this;
        }

        public ComparisonConfig build() {
            if (businessKeys.isEmpty()) {
                throw new IllegalStateException("At least one business key must be configured.");
            }
            return new ComparisonConfig(this);
        }
    }
}
