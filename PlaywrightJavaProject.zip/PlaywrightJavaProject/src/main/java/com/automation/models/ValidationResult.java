package com.automation.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Holds the complete outcome of a UI-to-database dataset comparison.
 *
 * <p>The database dataset is the expected result; the UI dataset is the actual result.
 */
public class ValidationResult {

    private boolean passed;
    private int dbRowCount;
    private int uiRowCount;
    private int matchedRowCount;
    private int mismatchedRowCount;
    private int missingInUiCount;
    private int missingInDbCount;
    private int fieldMismatchCount;
    private String summary;
    private final List<FieldMismatch> mismatches = new ArrayList<>();
    private final List<String> missingInUiKeys  = new ArrayList<>();
    private final List<String> missingInDbKeys  = new ArrayList<>();

    // -------------------------------------------------------------------------
    // Builder-style setters
    // -------------------------------------------------------------------------

    public ValidationResult passed(boolean passed)                     { this.passed = passed; return this; }
    public ValidationResult dbRowCount(int count)                      { this.dbRowCount = count; return this; }
    public ValidationResult uiRowCount(int count)                      { this.uiRowCount = count; return this; }
    public ValidationResult matchedRowCount(int count)                 { this.matchedRowCount = count; return this; }
    public ValidationResult mismatchedRowCount(int count)              { this.mismatchedRowCount = count; return this; }
    public ValidationResult missingInUiCount(int count)                { this.missingInUiCount = count; return this; }
    public ValidationResult missingInDbCount(int count)                { this.missingInDbCount = count; return this; }
    public ValidationResult fieldMismatchCount(int count)              { this.fieldMismatchCount = count; return this; }
    public ValidationResult summary(String summary)                    { this.summary = summary; return this; }

    public void addMismatch(FieldMismatch mismatch)                    { mismatches.add(mismatch); }
    public void addMissingInUiKey(String key)                          { missingInUiKeys.add(key); }
    public void addMissingInDbKey(String key)                          { missingInDbKeys.add(key); }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    public boolean isPassed()              { return passed; }
    public int getDbRowCount()             { return dbRowCount; }
    public int getUiRowCount()             { return uiRowCount; }
    public int getMatchedRowCount()        { return matchedRowCount; }
    public int getMismatchedRowCount()     { return mismatchedRowCount; }
    public int getMissingInUiCount()       { return missingInUiCount; }
    public int getMissingInDbCount()       { return missingInDbCount; }
    public int getFieldMismatchCount()     { return fieldMismatchCount; }
    public String getSummary()             { return summary; }
    public List<FieldMismatch> getMismatches()    { return Collections.unmodifiableList(mismatches); }
    public List<String> getMissingInUiKeys()      { return Collections.unmodifiableList(missingInUiKeys); }
    public List<String> getMissingInDbKeys()      { return Collections.unmodifiableList(missingInDbKeys); }

    @Override
    public String toString() {
        return String.format("ValidationResult{passed=%b, db=%d, ui=%d, matched=%d, mismatched=%d, " +
                "missingUI=%d, missingDB=%d, fieldMismatches=%d}",
                passed, dbRowCount, uiRowCount, matchedRowCount, mismatchedRowCount,
                missingInUiCount, missingInDbCount, fieldMismatchCount);
    }
}
