package com.automation.models;

/**
 * Represents a single field-level mismatch found during dataset comparison.
 */
public class FieldMismatch {

    private final String rowKey;
    private final String columnName;
    private final String expectedValue;
    private final String actualValue;
    private final String mismatchType;
    private final String message;

    public FieldMismatch(String rowKey, String columnName,
                         String expectedValue, String actualValue,
                         String mismatchType, String message) {
        this.rowKey        = rowKey;
        this.columnName    = columnName;
        this.expectedValue = expectedValue;
        this.actualValue   = actualValue;
        this.mismatchType  = mismatchType;
        this.message       = message;
    }

    public String getRowKey()        { return rowKey; }
    public String getColumnName()    { return columnName; }
    public String getExpectedValue() { return expectedValue; }
    public String getActualValue()   { return actualValue; }
    public String getMismatchType()  { return mismatchType; }
    public String getMessage()       { return message; }

    @Override
    public String toString() {
        return String.format("FieldMismatch{row='%s', col='%s', expected='%s', actual='%s', type='%s'}",
                rowKey, columnName, expectedValue, actualValue, mismatchType);
    }
}
