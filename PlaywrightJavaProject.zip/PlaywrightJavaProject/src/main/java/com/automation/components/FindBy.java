package com.automation.components;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a {@link PageElement} field with its locator strategy.
 *
 * <p>Usage:
 * <pre>{@code
 * @FindBy(css = "#submit-btn")
 * private PageElement submitButton;
 *
 * @FindBy(xpath = "//table[@class='visual-table']")
 * private PageElement dataTable;
 *
 * @FindBy(role = "button", name = "Sign In")
 * private PageElement signInButton;
 * }</pre>
 *
 * Call {@code ElementFactory.initElements(page, this)} in the page constructor
 * to inject all annotated fields.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface FindBy {

    /** CSS selector. */
    String css() default "";

    /** XPath expression. */
    String xpath() default "";

    /** ARIA role (use with {@link #name()}). */
    String role() default "";

    /** Accessible name — used together with {@link #role()}. */
    String name() default "";

    /** Text content match. */
    String text() default "";

    /** ARIA label attribute. */
    String label() default "";

    /** Test ID attribute (data-testid). */
    String testId() default "";

    /** Placeholder attribute. */
    String placeholder() default "";
}
