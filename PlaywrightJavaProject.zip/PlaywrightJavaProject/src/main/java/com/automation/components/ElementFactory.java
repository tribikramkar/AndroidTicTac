package com.automation.components;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.lang.reflect.Field;

/**
 * Initializes all {@link PageElement} fields annotated with {@link FindBy}
 * in a page object instance.
 *
 * <p>This is the Playwright equivalent of Selenium's {@code PageFactory.initElements()}.
 *
 * <p>Call it in every page object constructor:
 * <pre>{@code
 * public MyPage(Page page) {
 *     super(page);
 *     ElementFactory.initElements(page, this);
 * }
 * }</pre>
 *
 * <p>Supported locator strategies (evaluated in priority order):
 * <ol>
 *   <li>{@code css}       — CSS selector</li>
 *   <li>{@code xpath}     — XPath expression</li>
 *   <li>{@code role}      — ARIA role (optionally combined with {@code name})</li>
 *   <li>{@code text}      — exact or partial text match</li>
 *   <li>{@code label}     — accessible label</li>
 *   <li>{@code testId}    — data-testid attribute</li>
 *   <li>{@code placeholder} — placeholder attribute</li>
 * </ol>
 */
public final class ElementFactory {

    private static final Logger log = LogManager.getLogger(ElementFactory.class);

    private ElementFactory() {}

    /**
     * Scans {@code pageObject} and all its superclasses for {@link PageElement} fields
     * annotated with {@link FindBy}, creates the corresponding Playwright {@link Locator},
     * and injects a {@link PageElement} instance into each field.
     *
     * @param page       the Playwright {@link Page} to create locators against
     * @param pageObject the page object instance whose fields will be initialized
     * @throws RuntimeException if a field cannot be injected
     */
    public static void initElements(Page page, Object pageObject) {
        Class<?> clazz = pageObject.getClass();
        while (clazz != null && clazz != Object.class) {
            for (Field field : clazz.getDeclaredFields()) {
                if (field.isAnnotationPresent(FindBy.class)
                        && field.getType().equals(PageElement.class)) {
                    injectField(page, pageObject, field);
                }
            }
            clazz = clazz.getSuperclass();
        }
        log.debug("initElements complete for: {}", pageObject.getClass().getSimpleName());
    }

    private static void injectField(Page page, Object pageObject, Field field) {
        FindBy annotation = field.getAnnotation(FindBy.class);
        String description = pageObject.getClass().getSimpleName() + "." + field.getName();

        Locator locator = buildLocator(page, annotation, description);
        PageElement element = new PageElement(locator, description);

        field.setAccessible(true);
        try {
            field.set(pageObject, element);
            log.debug("Injected PageElement '{}' with strategy: {}", description, describeStrategy(annotation));
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Failed to inject PageElement into field: " + description, e);
        }
    }

    private static Locator buildLocator(Page page, FindBy annotation, String description) {
        if (!annotation.css().isBlank()) {
            return page.locator(annotation.css());
        }
        if (!annotation.xpath().isBlank()) {
            return page.locator("xpath=" + annotation.xpath());
        }
        if (!annotation.role().isBlank()) {
            AriaRole ariaRole = parseRole(annotation.role(), description);
            if (!annotation.name().isBlank()) {
                return page.getByRole(ariaRole, new Page.GetByRoleOptions().setName(annotation.name()));
            }
            return page.getByRole(ariaRole);
        }
        if (!annotation.text().isBlank()) {
            return page.getByText(annotation.text());
        }
        if (!annotation.label().isBlank()) {
            return page.getByLabel(annotation.label());
        }
        if (!annotation.testId().isBlank()) {
            return page.getByTestId(annotation.testId());
        }
        if (!annotation.placeholder().isBlank()) {
            return page.getByPlaceholder(annotation.placeholder());
        }
        throw new IllegalArgumentException(
                "No locator strategy defined in @FindBy on field: " + description +
                ". Provide at least one of: css, xpath, role, text, label, testId, placeholder.");
    }

    private static AriaRole parseRole(String role, String description) {
        try {
            return AriaRole.valueOf(role.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(
                    "Invalid ARIA role '" + role + "' on field: " + description +
                    ". Valid values: " + java.util.Arrays.toString(AriaRole.values()), e);
        }
    }

    private static String describeStrategy(FindBy annotation) {
        if (!annotation.css().isBlank())         return "css=" + annotation.css();
        if (!annotation.xpath().isBlank())       return "xpath=" + annotation.xpath();
        if (!annotation.role().isBlank())        return "role=" + annotation.role() + (annotation.name().isBlank() ? "" : "[name=" + annotation.name() + "]");
        if (!annotation.text().isBlank())        return "text=" + annotation.text();
        if (!annotation.label().isBlank())       return "label=" + annotation.label();
        if (!annotation.testId().isBlank())      return "testId=" + annotation.testId();
        if (!annotation.placeholder().isBlank()) return "placeholder=" + annotation.placeholder();
        return "unknown";
    }
}
