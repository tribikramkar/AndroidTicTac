package com.automation.components;

import com.automation.exceptions.PageException;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.options.WaitForSelectorState;

import java.util.ArrayList;
import java.util.List;

/**
 * Wraps a Playwright {@link Locator} and exposes fluent interaction methods.
 *
 * <p>This is the Playwright equivalent of Selenium's {@code WebElement}.
 * Instances are created and injected by {@link ElementFactory#initElements}.
 *
 * <p>The underlying {@link Locator} is lazy — it is resolved against the live DOM
 * at the time each action is called, so stale element issues do not occur.
 */
public class PageElement {

    private final Locator locator;
    private final String description;

    public PageElement(Locator locator, String description) {
        this.locator = locator;
        this.description = description;
    }

    // -------------------------------------------------------------------------
    // Actions
    // -------------------------------------------------------------------------

    public void click() {
        try {
            locator.click();
        } catch (Exception e) {
            throw new PageException("Click failed on [" + description + "]: " + e.getMessage(), e);
        }
    }

    public void fill(String value) {
        try {
            locator.fill(value);
        } catch (Exception e) {
            throw new PageException("Fill failed on [" + description + "]: " + e.getMessage(), e);
        }
    }

    public void selectOption(String value) {
        try {
            locator.selectOption(value);
        } catch (Exception e) {
            throw new PageException("SelectOption failed on [" + description + "]: " + e.getMessage(), e);
        }
    }

    public void hover() {
        try {
            locator.hover();
        } catch (Exception e) {
            throw new PageException("Hover failed on [" + description + "]: " + e.getMessage(), e);
        }
    }

    public void clear() {
        try {
            locator.clear();
        } catch (Exception e) {
            throw new PageException("Clear failed on [" + description + "]: " + e.getMessage(), e);
        }
    }

    // -------------------------------------------------------------------------
    // Reading
    // -------------------------------------------------------------------------

    public String getText() {
        try {
            return locator.innerText().strip();
        } catch (Exception e) {
            throw new PageException("getText failed on [" + description + "]: " + e.getMessage(), e);
        }
    }

    public String getAttribute(String attribute) {
        try {
            return locator.getAttribute(attribute);
        } catch (Exception e) {
            throw new PageException("getAttribute('" + attribute + "') failed on [" + description + "]: " + e.getMessage(), e);
        }
    }

    public String getInputValue() {
        try {
            return locator.inputValue();
        } catch (Exception e) {
            throw new PageException("getInputValue failed on [" + description + "]: " + e.getMessage(), e);
        }
    }

    // -------------------------------------------------------------------------
    // State
    // -------------------------------------------------------------------------

    public boolean isVisible() {
        try {
            return locator.isVisible();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isEnabled() {
        try {
            return locator.isEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isChecked() {
        try {
            return locator.isChecked();
        } catch (Exception e) {
            return false;
        }
    }

    public int count() {
        return locator.count();
    }

    // -------------------------------------------------------------------------
    // Waiting
    // -------------------------------------------------------------------------

    public void waitForVisible() {
        try {
            locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
        } catch (Exception e) {
            throw new PageException("Timed out waiting for [" + description + "] to be visible.", e);
        }
    }

    public void waitForVisible(double timeoutMs) {
        try {
            locator.waitFor(new Locator.WaitForOptions()
                    .setState(WaitForSelectorState.VISIBLE)
                    .setTimeout(timeoutMs));
        } catch (Exception e) {
            throw new PageException("Timed out waiting for [" + description + "] to be visible.", e);
        }
    }

    public void waitForHidden() {
        try {
            locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN));
        } catch (Exception e) {
            throw new PageException("Timed out waiting for [" + description + "] to be hidden.", e);
        }
    }

    // -------------------------------------------------------------------------
    // Multi-element helpers
    // -------------------------------------------------------------------------

    /**
     * Returns a {@link PageElement} for the nth match (0-based).
     */
    public PageElement nth(int index) {
        return new PageElement(locator.nth(index), description + "[" + index + "]");
    }

    /**
     * Returns all matched elements as individual {@link PageElement} instances.
     */
    public List<PageElement> all() {
        int total = locator.count();
        List<PageElement> elements = new ArrayList<>(total);
        for (int i = 0; i < total; i++) {
            elements.add(new PageElement(locator.nth(i), description + "[" + i + "]"));
        }
        return elements;
    }

    /**
     * Returns a child {@link PageElement} using a CSS selector relative to this element.
     */
    public PageElement find(String childSelector) {
        return new PageElement(locator.locator(childSelector), description + " > " + childSelector);
    }

    // -------------------------------------------------------------------------
    // Raw access
    // -------------------------------------------------------------------------

    /** Returns the underlying Playwright {@link Locator} for advanced use cases. */
    public Locator getLocator() {
        return locator;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return "PageElement[" + description + "]";
    }
}
