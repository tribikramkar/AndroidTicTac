-- =============================================================================
-- Power BI Dashboard Validation Query
-- =============================================================================
-- Replace this query with your actual SELECT statement.
-- Use ? placeholders for parameterized values.
-- Only SELECT statements are permitted in validation tests.
-- =============================================================================

SELECT
    [YourKeyColumn]       AS KeyColumn,
    [YourMetricColumn1]   AS MetricColumn1,
    [YourMetricColumn2]   AS MetricColumn2,
    [YourDateColumn]      AS DateColumn
FROM
    [dbo].[YourTable]
WHERE
    [YourFilterColumn] = ?
ORDER BY
    [YourKeyColumn];
